# AutoDub — Next.js landing page

A 1:1 port of `AutoDub Hero.dc.html`. Same markup, inline styles, animations and logic, now running as a Next.js App Router site.

## Project structure

```
app/
  layout.jsx      <html>, fonts (Geist + Pinyon Script), SEO metadata
  page.jsx        Home route: renders <AutoDubLanding />
  globals.css     Body resets + hover/focus/active states
  icon.svg        Favicon
components/
  AutoDubLanding.jsx   The whole landing page (client component)
test/preview.html      Browser-only preview, no install needed (not part of the site)
test/mobile.html       Same, at a fixed phone/tablet width (set localStorage __mw, e.g. 375)
```

## Responsive breakpoints

- **< 760px (phones):** mobile layouts for Features, Use cases (stacked tilted cards) and FAQ; How it works becomes a single centred column of cards.
- **< 1000px:** Pricing cards stack; How it works uses the single-column layout.
- **< 1024px:** the header switches to the hamburger menu.
- **< 1100px:** Use cases switches from the tilted collage to a card grid (1 column on phones, 2 on tablets).
- **≥ 1100px:** full desktop design.

Tested at 320, 375, 768 and 1024px wide. Check on real devices before launch, especially the scroll-pinned How it works section.

---

## 1. Run it locally

You need **Node.js 20.9 or newer** (check with `node -v`; get it from nodejs.org).

```bash
cd autodub-next
npm install
npm run dev
```

Open http://localhost:3000. Scroll the whole page and check that the preloader, nav lens, grid hover, feature cards, How it works, Use cases, Pricing toggle and FAQ all behave like the design.

## 2. Production build check

```bash
npm run build
npm start
```

If `build` passes, the site is ready to deploy.

## 3. Put the code on GitHub

1. Create an empty repo on github.com, for example `autodub-landing`.
2. Run:

```bash
git init
git add .
git commit -m "AutoDub landing page"
git branch -M main
git remote add origin https://github.com/<you>/autodub-landing.git
git push -u origin main
```

## 4. Deploy on Vercel (recommended, free tier works)

1. Go to vercel.com and sign in with GitHub.
2. **Add New → Project**, import `autodub-landing`.
3. Vercel detects Next.js. Leave the defaults and click **Deploy**.
4. You get a live URL like `autodub-landing.vercel.app`.

After this, every `git push` to `main` redeploys automatically.

## 5. Connect your domain

In Vercel: **Project → Settings → Domains → Add**, then enter `yourdomain.com` and `www.yourdomain.com`.

At your domain registrar (GoDaddy, Namecheap, Cloudflare and so on), add the DNS records Vercel shows you. They are usually:

| Type  | Name | Value |
|-------|------|-------|
| A     | @    | the IP shown in Vercel |
| CNAME | www  | the CNAME target shown in Vercel |

Always copy the exact values from the Vercel Domains screen; they can differ per project.

- DNS usually updates in minutes, but it can take up to 48 hours.
- Vercel issues the HTTPS certificate automatically.
- Set one of the two domains (`yourdomain.com` or `www`) as primary; the other redirects to it.
- **Using Cloudflare DNS:** set these records to "DNS only" (grey cloud) so Vercel can issue the certificate.

## 6. Alternatives to Vercel

- **Netlify:** import the repo; it detects Next.js automatically. Add your domain under Domain management.
- **Your own server (VPS):** run `npm run build`, then `npm start` (port 3000), keep it alive with a process manager such as pm2, and put Nginx in front as a reverse proxy with SSL from Let's Encrypt.

---

## Before you launch

- **Images:** avatars and the hero photo load from Unsplash. Replace them with your own files: put them in `public/` and change the `src`, for example `/hero.jpg`.
- **Links:** most buttons point to `#`. Search `href="#"` in `components/AutoDubLanding.jsx` and set real URLs (sign-up, login, socials).
- **Copy and SEO:** edit the title and description in `app/layout.jsx`. Add `app/opengraph-image.png` (1200×630) for link previews.
- **Email:** the footer uses `hello@autodub.ai` and `support@autodub.ai`; change them if needed.
- **Analytics (optional):** `npm i @vercel/analytics`, then add `<Analytics />` from `@vercel/analytics/next` inside `<body>` in `app/layout.jsx`.

## Editing the design

- Each section is plain JSX inside `render()` in `components/AutoDubLanding.jsx`. Search for the section `id` (`features`, `how-it-works`, `use-cases`, `pricing`, `faq`).
- Styles are inline `style={{ … }}` objects. Hover and focus states are classes named `adp0`–`adp13` in `app/globals.css`.
- Text and data lists (FAQ, pricing rows, use cases) are in `renderVals()`, near the bottom of the class.
- Animations use requestAnimationFrame and the Web Animations API in the methods `setupHow`, `setupFx`, `runPreloader` and so on.
