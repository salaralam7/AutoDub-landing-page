'use client';

import React from 'react';

class AutoDubLanding extends React.Component {
  state = { active: 0, hover: null, rects: null, squish: false, mobile: false, menuOpen: false, compact: false, ucS: false, prS: false };
  tiersFor(w) { return { compact: w < 1024, ucS: w < 1100, prS: w < 1000 }; }
  waveRef = React.createRef();
  svgRef = React.createRef();
  navRef = React.createRef();
  trustRef = React.createRef();
  startTrustFx(delay) {
    const el = this.trustRef.current; if (!el || (this.rm && this.rm.matches)) return;
    const text = '1420+ monthly users';
    el.style.minWidth = el.offsetWidth + 'px';
    let i = 0;
    const erase = () => {
      if (!el.isConnected) return;
      i -= 1; el.textContent = text.slice(0, Math.max(0, i));
      this.trustT = i > 0 ? setTimeout(erase, 28) : setTimeout(type, 260);
    };
    const type = () => {
      if (!el.isConnected) return;
      i += 1; el.textContent = text.slice(0, i);
      this.trustT = i < text.length ? setTimeout(type, 60) : setTimeout(erase, 4000);
    };
    this.trustT = setTimeout(() => { i = text.length; erase(); }, delay);
  }
  ss = { y: 0, t: 0, on: false };
  goSec(i) {
    const id = [null, 'features', 'how-it-works', 'use-cases', 'pricing'][i];
    const el = id && document.getElementById(id);
    const y = el ? el.getBoundingClientRect().top + window.scrollY : 0;
    this.ss.on = false;
    window.scrollTo({ top: Math.max(0, y), behavior: (this.rm && this.rm.matches) ? 'auto' : 'smooth' });
  }
  onWheel = e => {
    if (e.ctrlKey || (this.rm && this.rm.matches)) return;
    e.preventDefault();
    if (document.documentElement.style.overflow === 'hidden') return;
    const ss = this.ss, max = document.documentElement.scrollHeight - window.innerHeight;
    if (!ss.on) { ss.y = ss.t = window.scrollY; }
    const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? window.innerHeight : 1);
    ss.t = Math.max(0, Math.min(max, ss.t + dy * 0.78)); ss.on = true;
  };
  ssTick() {
    const ss = this.ss; if (!ss.on) return;
    ss.y += (ss.t - ss.y) * 0.11;
    if (Math.abs(ss.t - ss.y) < 0.4) { ss.y = ss.t; ss.on = false; }
    window.scrollTo(0, ss.y);
  }
  cbSvgRef = React.createRef();
  cb = { w: 0, h: 0, r: 0 };
  cbLayout = () => {
    const el = this.videoInRef.current, svg = this.cbSvgRef.current; if (!el || !svg) return;
    const w = el.offsetWidth, h = el.offsetHeight, r = Math.min(parseFloat(getComputedStyle(el).borderTopLeftRadius) || 20, h / 2);
    this.cb = { w, h, r };
    svg.querySelectorAll('rect').forEach(q => { q.setAttribute('x', 24.5); q.setAttribute('y', 24.5); q.setAttribute('width', Math.max(0, w - 1)); q.setAttribute('height', Math.max(0, h - 1)); q.setAttribute('rx', r); });
    if (!this.cbG) this.cbG = [svg.querySelector('#cbEdge'), svg.querySelector('#cbEdge2')];
    this.cbG.forEach(g => g && g.setAttribute('r', Math.max(220, Math.min(w, h) * 0.75).toFixed(0)));
  };
  cbTick(now) {
    const { w, h, r } = this.cb; if (!w || !this.cbG) return;
    const L = w - 2 * r, H = h - 2 * r, A = Math.PI * r / 2, P = 2 * L + 2 * H + 4 * A;
    const base = (this.rm && this.rm.matches) ? L * 0.3 : (((now / 1000) % 2.3) / 2.3) * P;
    this.cbG.forEach((g, k) => { if (g) this.cbPt(g, (base + k * P / 2) % P, w, h, r, L, H, A); });
  }
  cbPt(g, d, w, h, r, L, H, A) {
    let x, y; const o = 24;
    if (d < L) { x = r + d; y = 0; }
    else if ((d -= L) < A) { const a = -Math.PI / 2 + d / r; x = w - r + Math.cos(a) * r; y = r + Math.sin(a) * r; }
    else if ((d -= A) < H) { x = w; y = r + d; }
    else if ((d -= H) < A) { const a = d / r; x = w - r + Math.cos(a) * r; y = h - r + Math.sin(a) * r; }
    else if ((d -= A) < L) { x = w - r - d; y = h; }
    else if ((d -= L) < A) { const a = Math.PI / 2 + d / r; x = r + Math.cos(a) * r; y = h - r + Math.sin(a) * r; }
    else if ((d -= A) < H) { x = 0; y = h - r - d; }
    else { d -= H; const a = Math.PI + d / r; x = r + Math.cos(a) * r; y = r + Math.sin(a) * r; }
    g.setAttribute('cx', (o + x).toFixed(1)); g.setAttribute('cy', (o + y).toFixed(1));
  }
  preRef = React.createRef(); preTopRef = React.createRef(); preBotRef = React.createRef(); preLogoRef = React.createRef();
  headerRef = React.createRef(); heroInRef = React.createRef(); videoInRef = React.createRef(); tkTrackRef = React.createRef(); tkGroupRef = React.createRef(); probRef = React.createRef();
  howRef = React.createRef(); howTrackRef = React.createRef(); ucRef = React.createRef();
  ucApply(instant) {
    const root = this.ucRef.current; if (!root) return;
    root.querySelectorAll('[data-uc]').forEach(el => { if (instant) el.style.transition = 'none'; else el.style.transitionDelay = ((parseFloat(el.getAttribute('data-uc')) || 0) * 0.08) + 's'; el.style.opacity = '1'; el.style.transform = 'none'; });
  }
  prRef = React.createRef();
  setupPr() {
    const show = instant => { const el = this.prRef.current; if (!el) return; el.querySelectorAll('[data-pr]').forEach(c => { if (instant) c.style.transition = 'none'; else c.style.transitionDelay = (parseFloat(c.getAttribute('data-pr')) * 0.08) + 's'; c.style.opacity = '1'; c.style.transform = 'none'; }); };
    if (this.rm && this.rm.matches) { show(true); return; }
    this.prCheck = () => { const el = this.prRef.current; if (!el) return; const r = el.getBoundingClientRect(); if (r.top < window.innerHeight * 0.75 && r.bottom > 0) { show(false); window.removeEventListener('scroll', this.prCheck); window.removeEventListener('resize', this.prCheck); } };
    window.addEventListener('scroll', this.prCheck, { passive: true }); window.addEventListener('resize', this.prCheck);
    requestAnimationFrame(this.prCheck);
  }
  faqRef = React.createRef();
  setupFaq() {
    const show = instant => { const el = this.faqRef.current; if (!el) return; el.querySelectorAll('[data-fq]').forEach(c => { if (instant) c.style.transition = 'none'; else c.style.transitionDelay = (parseFloat(c.getAttribute('data-fq')) * 0.07) + 's'; c.style.opacity = '1'; c.style.transform = 'none'; }); };
    if (this.rm && this.rm.matches) { show(true); return; }
    this.fqCheck = () => { const el = this.faqRef.current; if (!el) return; const r = el.getBoundingClientRect(); if (r.top < window.innerHeight * 0.8 && r.bottom > 0) { show(false); window.removeEventListener('scroll', this.fqCheck); window.removeEventListener('resize', this.fqCheck); } };
    window.addEventListener('scroll', this.fqCheck, { passive: true }); window.addEventListener('resize', this.fqCheck);
    requestAnimationFrame(this.fqCheck);
  }
  setupUc() {
    const root = this.ucRef.current; if (!root) return;
    const canHover = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches && !(this.rm && this.rm.matches);
    if (canHover) {
      let cur = null;
      const reset = c => { if (c) c.style.transform = ''; };
      this.ucMove = e => {
        const c = e.target.closest && e.target.closest('[data-uc-card]');
        if (c !== cur) { reset(cur); cur = c; }
        if (!c) return;
        const r = c.parentElement.getBoundingClientRect();
        const x = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width) * 2 - 1)), y = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height) * 2 - 1));
        c.style.transform = `perspective(1100px) translate3d(${(-x * 14).toFixed(1)}px, ${(-y * 10 - 16).toFixed(1)}px, 0) rotateX(${(-y * 11).toFixed(2)}deg) rotateY(${(x * 11).toFixed(2)}deg) scale(1.05)`;
      };
      this.ucLeave = () => { reset(cur); cur = null; };
      root.addEventListener('mousemove', this.ucMove); root.addEventListener('mouseleave', this.ucLeave);
    }
    if ((this.rm && this.rm.matches) || typeof IntersectionObserver === 'undefined') { this.ucShown = true; this.ucApply(true); return; }
    this.ucCheck = () => {
      if (this.ucShown) return;
      const el = this.ucRef.current; if (!el) return;
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight * 0.8 && r.bottom > 0) { this.ucShown = true; this.ucApply(false); window.removeEventListener('scroll', this.ucCheck); window.removeEventListener('resize', this.ucCheck); }
    };
    window.addEventListener('scroll', this.ucCheck, { passive: true }); window.addEventListener('resize', this.ucCheck);
    requestAnimationFrame(this.ucCheck);
  }
  setupHow() {
    const sec = this.howRef.current, st = this.howTrackRef.current; if (!sec || !st) return;
    const D = [7, 69, 13, 63], M = [5, 21, 5, 21];
    this.hw = { sec, st, cards: Array.from(sec.querySelectorAll('[data-hw-card]')), glow: sec.querySelector('[data-hw-glow]'), logo: sec.querySelector('[data-hw-logo]'), title: sec.querySelector('[data-hw-title]'), big: sec.querySelector('[data-hw-big]'), lines: Array.from(sec.querySelectorAll('[data-hw-l]')), side: Array.from(sec.querySelectorAll('[data-hw-s]')), cur: null, ch: [] };
    this.hwMeasure = () => {
      const H = this.hw, narrow = st.clientWidth < 1000; H.vh = st.clientHeight; H.narrow = narrow;
      const w = narrow ? 'min(86%, 360px)' : 'min(23%, 330px)';
      H.cards.forEach((c, i) => { c.style.width = w; c.style.left = narrow ? 'calc((100% - min(86%, 360px)) / 2)' : D[i] + '%'; });
      H.sec.style.height = narrow ? '330svh' : '';
      H.ch = H.cards.map(c => c.offsetHeight); H.secH = H.sec.offsetHeight;
    };
    this.hwMeasure(); window.addEventListener('resize', this.hwMeasure);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => this.hwMeasure());
    if (this.rm && this.rm.matches) { this.hwFrame(0); }
    const loop = now => { this.hwRaf = null; if (!this.hwOn) return; this.hwFrame(now); this.hwRaf = requestAnimationFrame(loop); };
    this.hwKick = () => { const r = sec.getBoundingClientRect(); this.hwOn = r.bottom > -200 && r.top < window.innerHeight + 200; if (this.hwOn && !this.hwRaf) this.hwRaf = requestAnimationFrame(loop); };
    window.addEventListener('scroll', this.hwKick, { passive: true }); this.hwKick();
    if (typeof IntersectionObserver === 'undefined') return;
    this.hwIO = new IntersectionObserver(es => { this.hwOn = es[0].isIntersecting; if (this.hwOn && !this.hwRaf) { this.hwMeasure(); this.hwRaf = requestAnimationFrame(loop); } }, { rootMargin: '200px 0px' });
    this.hwIO.observe(sec);
  }
  hwFrame(now) {
    const H = this.hw, r = H.sec.getBoundingClientRect(), range = Math.max(1, (H.secH || H.sec.offsetHeight) - (H.vh || window.innerHeight));
    const rm = this.rm && this.rm.matches;
    const raw = -r.top / range, tgt = rm ? 0.42 : Math.min(1.08, Math.max(-0.08, raw));
    H.cur = H.cur == null || rm ? tgt : H.cur + (tgt - H.cur) * 0.16;
    if (Math.abs(tgt - H.cur) < 0.0004) H.cur = tgt;
    const p = H.cur, vh = H.vh || window.innerHeight;
    const A = [0.55, 0.9, 1.25, 1.6], S = [1.08, 1.1, 1.12, 1.1];
    const gp = (Math.max(0, ...H.ch) || vh * 0.4) + 20;
    H.cards.forEach((c, i) => {
      const yc = H.narrow ? vh * 0.72 + i * gp - p * (vh * 0.3 + 3 * gp) : vh * (rm ? 0.22 + i * 0.2 : A[i] - p * S[i]);
      c.style.transform = 'translate3d(0,' + (yc - (H.ch[i] || 0) / 2).toFixed(1) + 'px,0)';
    });
    const t = (now || 0) / 1000; let en = 0;
    if (!rm) H.lines.forEach(l => {
      const i = +l.dataset.i, m = +l.dataset.m, len = +l.dataset.l;
      const k = 0.42 + 0.58 * Math.abs(Math.sin(t * 2.3 + i * 0.74) * Math.sin(t * 1.15 + i * 0.37 + 0.6));
      if (l.dataset.c === '1') en += k;
      const h = len * k / 2; l.setAttribute('y1', (m - h).toFixed(1)); l.setAttribute('y2', (m + h).toFixed(1));
    });
    if (!rm) H.side.forEach(l => {
      const i = +l.dataset.i, m = +l.dataset.m, len = +l.dataset.l;
      const h = len * (0.5 + 0.5 * Math.abs(Math.sin(t * 1.9 - i * 0.45) * Math.sin(t * 0.9 + i * 0.23))) / 2;
      l.setAttribute('y1', (m - h).toFixed(1)); l.setAttribute('y2', (m + h).toFixed(1));
    });
    en = rm ? 0.8 : en / 8;
    const vis = Math.min(1, Math.max(0, (p + 0.12) / 0.22));
    if (H.glow) H.glow.style.opacity = ((0.35 + 0.65 * en) * vis).toFixed(3);
    if (H.logo) H.logo.style.transform = 'translate3d(-50%,calc(-50% + ' + (-Math.max(0, p) * vh * 0.06).toFixed(1) + 'px),0)';
    if (H.title) H.title.style.transform = 'translate3d(0,' + (-Math.max(0, p) * vh * 0.06).toFixed(1) + 'px,0)';
  }
  setupFx() {
    const root = this.probRef.current; if (!root) return;
    const q = s => Array.from(root.querySelectorAll(s)), o = s => root.querySelector(s);
    this.fx = { spk: q('[data-spk-bar]'), av: q('[data-spk-av]'), emo: q('[data-emo-path]'), emoTag: o('[data-emo-tag]'), ctx: o('[data-ctx-out]'), ctxL: o('[data-ctx-lang]'), caret: o('[data-ctx-caret]'), id: q('[data-id-bar]'), head: o('[data-sync-head]'), tc: o('[data-sync-tc]'), segs: q('[data-sync-seg]'), bg: q('[data-bg-bar]'), bgL: o('[data-bg-lang]'), es: { a: 14, f: 1.2, s: 1.4, ph: 0 }, last: {} };
    this.fxFrame(1.7); this.fx.spk = []; this.fx.av = []; this.fx.bg = [];
    if ((this.rm && this.rm.matches) || typeof IntersectionObserver === 'undefined') return;
    const loop = now => { this.fxRaf = null; if (!this.fxOn) return; this.fxFrame(now / 1000); this.fxRaf = requestAnimationFrame(loop); };
    this.fxIO = new IntersectionObserver(es => { this.fxOn = es[0].isIntersecting; if (this.fxOn && !this.fxRaf) this.fxRaf = requestAnimationFrame(loop); }, { rootMargin: '120px' });
    this.fxIO.observe(root);
  }
  fxFrame(t) {
    const f = this.fx, L = f.last, dt = Math.min(0.05, L.t == null ? 0 : t - L.t); L.t = t;
    const act = Math.floor(t / 1.6) % 3;
    f.spk.forEach((el, i) => { const on = +el.dataset.g === act, n = Math.abs(Math.sin(t * 5.2 + i * 1.3) * Math.sin(t * 1.9 + i * 0.47)); el.style.transform = 'scaleY(' + (on ? 0.25 + 0.75 * n : 0.1 + 0.12 * n).toFixed(3) + ')'; el.style.opacity = on ? '1' : '0.35'; });
    if (L.act !== act) { L.act = act; f.av.forEach((el, i) => { el.style.opacity = i === act ? '1' : '0.45'; el.style.transform = i === act ? 'scale(1.1)' : 'scale(1)'; }); }
    const E = [{ n: 'Calm', a: 12, f: 1.2, s: 1.4 }, { n: 'Excited', a: 42, f: 3.4, s: 6 }, { n: 'Whisper', a: 5, f: 2.4, s: 2 }, { n: 'Joyful', a: 30, f: 2.2, s: 3.6 }];
    const ei = Math.floor(t / 2.6) % E.length, tg = E[ei], s = f.es, k = Math.min(1, dt * 4);
    s.a += (tg.a - s.a) * k; s.f += (tg.f - s.f) * k; s.s += (tg.s - s.s) * k; s.ph += s.s * dt;
    if (dt === 0) { s.a = tg.a; s.f = tg.f; }
    f.emo.forEach(p => { const j = +p.dataset.j; let d = ''; for (let x = 0; x <= 300; x += 5) { const y = 60 + s.a * (j ? 0.6 : 1) * Math.sin(Math.PI * x / 300) * Math.sin((x / 300) * Math.PI * 2 * s.f + s.ph + j * 1.1); d += (x ? 'L' : 'M') + x + ' ' + y.toFixed(1); } p.setAttribute('d', d); });
    if (L.ei !== ei && f.emoTag) { L.ei = ei; f.emoTag.textContent = tg.n; }
    const T = [{ l: 'ES', t: 'Está lloviendo a cántaros.' }, { l: 'FR', t: 'Il pleut des cordes.' }, { l: 'DE', t: 'Es regnet in Strömen.' }, { l: 'JA', t: '土砂降りだ。' }];
    const P = 3.8, ci = Math.floor(t / P) % T.length, lt = t % P, ch = Array.from(T[ci].t);
    const n = lt < 1.1 ? Math.ceil(ch.length * lt / 1.1) : lt < 3.3 ? ch.length : Math.max(0, Math.floor(ch.length * (1 - (lt - 3.3) / 0.5)));
    const out = ch.slice(0, n).join('');
    if (f.ctx && L.ctx !== out) { L.ctx = out; f.ctx.textContent = out; }
    if (f.ctxL && L.ci !== ci) { L.ci = ci; f.ctxL.textContent = T[ci].l; }
    if (f.caret) f.caret.style.opacity = (lt > 1.1 && lt < 3.3 && Math.floor(t * 2.4) % 2) ? '0' : '1';
    f.id.forEach(el => { const i = +el.dataset.i; el.style.transform = 'scaleY(' + (0.18 + 0.82 * Math.abs(Math.sin(t * 3.1 + i * 0.55) * Math.cos(t * 1.3 + i * 0.21))).toFixed(3) + ')'; });
    const p = (t % 7) / 7, pc = p * 100;
    if (f.head) f.head.style.left = pc.toFixed(2) + '%';
    if (f.tc) { const sec = p * 24; f.tc.textContent = '00:' + String(Math.floor(sec)).padStart(2, '0') + '.' + Math.floor((sec % 1) * 10); }
    f.segs.forEach(el => { const on = pc >= +el.dataset.s && pc <= +el.dataset.e; if (el._on !== on) { el._on = on; el.style.opacity = on ? '1' : '0.5'; } });
    f.bg.forEach(el => { const i = +el.dataset.i, g = +el.dataset.g; el.style.transform = 'scaleY(' + (0.22 + 0.78 * Math.abs(Math.sin(t * (2.2 + g * 0.7) + i * 1.1) * Math.sin(t * 1.1 + i * 0.7 + g))).toFixed(3) + ')'; });
    const LG = ['ES', 'FR', 'DE', 'HI', 'JA'], li = Math.floor(t / 1.8) % LG.length;
    if (f.bgL && L.li !== li) { L.li = li; f.bgL.textContent = LG[li]; }
  }
  setupReveal() {
    const root = this.probRef.current; if (!root) return;
    const els = Array.from(root.querySelectorAll('[data-rv]'));
    const show = el => { el.style.transitionDelay = ((parseFloat(el.getAttribute('data-rv')) || 0) * 0.12) + 's'; el.style.opacity = '1'; el.style.transform = 'none'; el.style.filter = 'none'; if (el.tagName.toLowerCase() === 'path') el.style.strokeDashoffset = '0'; };
    if ((this.rm && this.rm.matches) || typeof IntersectionObserver === 'undefined') { els.forEach(el => { el.style.transition = 'none'; show(el); }); return; }
    this.rvIO = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { show(en.target); this.rvIO.unobserve(en.target); } }), { rootMargin: '0px 0px -12% 0px', threshold: 0.05 });
    els.forEach(el => this.rvIO.observe(el));
  }
  runPreloader() {
    const o = this.preRef.current; if (!o) return;
    if (this.props.preloader === false) { o.style.display = 'none'; return; }
    const root = document.documentElement, prevOv = root.style.overflow; root.style.overflow = 'hidden';
    const done = () => { o.style.display = 'none'; root.style.overflow = prevOv; this.measureNav && this.measureNav(); this.sbLayout && this.sbLayout(); };
    if (this.rm && this.rm.matches) { o.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 400, delay: 500, fill: 'forwards' }).onfinish = done; return; }
    const logo = this.preLogoRef.current, top = this.preTopRef.current, bot = this.preBotRef.current;
    const E = 'cubic-bezier(0.16, 1, 0.3, 1)', IO = 'cubic-bezier(0.76, 0, 0.24, 1)', DS = 'drop-shadow(0 0 22px rgba(72,96,255,0.45))';
    logo.animate([{ opacity: 0, transform: 'scale(0.86)' }, { opacity: 1, transform: 'scale(1)' }], { duration: 600, easing: E, fill: 'backwards' });
    logo.querySelectorAll('line').forEach((l, i) => {
      l.style.transformBox = 'fill-box'; l.style.transformOrigin = 'center';
      l.animate([{ transform: 'scaleY(1)' }, { transform: 'scaleY(0.3)' }, { transform: 'scaleY(1.12)' }, { transform: 'scaleY(0.55)' }, { transform: 'scaleY(1)' }], { duration: 760, delay: 250 + i * 70, iterations: 2, easing: 'ease-in-out' });
    });
    logo.querySelectorAll('circle').forEach(c => c.animate([{ opacity: 1 }, { opacity: 0.35 }, { opacity: 1 }], { duration: 760, delay: 250, iterations: 2, easing: 'ease-in-out' }));
    const T = 2250, O = T + 350;
    logo.animate([{ opacity: 1, transform: 'scale(1)', filter: DS + ' blur(0px)' }, { opacity: 0, transform: 'scale(1.3)', filter: DS + ' blur(6px)' }], { duration: 500, delay: T, easing: 'cubic-bezier(0.4, 0, 1, 1)', fill: 'forwards' });
    top.animate([{ transform: 'translateY(0)' }, { transform: 'translateY(-100%)' }], { duration: 1000, delay: O, easing: IO, fill: 'forwards' });
    bot.animate([{ transform: 'translateY(0)' }, { transform: 'translateY(100%)' }], { duration: 1000, delay: O, easing: IO, fill: 'forwards' });
    const h = this.headerRef.current, c = this.heroInRef.current, v = this.videoInRef.current;
    if (h) h.animate([{ opacity: 0, transform: 'translateY(-14px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 900, delay: O + 450, easing: E, fill: 'backwards' });
    if (c) {
      const parts = [];
      [...c.children].forEach(ch => { if (ch.tagName === 'H1') parts.push(...ch.children); else parts.push(ch); });
      parts.forEach((el, i) => el.animate([
        { opacity: 0, transform: 'translateY(34px) scale(0.97)', filter: 'blur(10px)' },
        { opacity: 1, transform: 'translateY(0) scale(1)', filter: 'blur(0px)' }
      ], { duration: 1200, delay: O + 250 + i * 130, easing: E, fill: 'backwards' }));
    }
    if (v) v.animate([{ opacity: 0, transform: 'translateY(60px) scale(0.94)' }, { opacity: 1, transform: 'translateY(0) scale(1)' }], { duration: 1400, delay: O + 500, easing: E, fill: 'backwards' });
    this.preT = setTimeout(done, O + 1050);
  }
  sbRef = React.createRef();
  sbSvgRef = React.createRef();
  sb = { x: 0, y: 0, tx: 0, ty: 0, w: 0, h: 0, on: false };
  sbIdle() { const b = this.sb; b.tx = 24 + b.w * 0.22; b.ty = 24; }
  sbLayout = () => {
    const el = this.sbRef.current, svg = this.sbSvgRef.current; if (!el || !svg) return;
    const w = el.offsetWidth, h = el.offsetHeight, b = this.sb; b.w = w; b.h = h;
    svg.querySelectorAll('rect').forEach(r => {
      const inset = r.dataset.sb === 'glow' ? 0 : 0.5;
      r.setAttribute('x', 24 + inset); r.setAttribute('y', 24 + inset);
      r.setAttribute('width', Math.max(0, w - inset * 2)); r.setAttribute('height', Math.max(0, h - inset * 2));
      r.setAttribute('rx', h / 2 - inset);
    });
    if (!b.on) { this.sbIdle(); if (!b.x) { b.x = b.tx; b.y = b.ty; } }
  };
  sbRO = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => this.sbLayout()) : null;
  sbMove = e => {
    if (this.sbRO && this.sbRef.current && !this.sbObs) { this.sbRO.observe(this.sbRef.current); this.sbObs = true; }
    const el = this.sbRef.current; if (!el) return;
    const r = el.getBoundingClientRect(), b = this.sb;
    b.on = true; b.tx = 24 + (e.clientX - r.left); b.ty = 24 + (e.clientY - r.top);
  };
  sbLeave = () => { this.sb.on = false; this.sbIdle(); };
  lensRef = React.createRef();
  lgSvgRef = React.createRef();
  lgCache = {};
  lgOK = typeof navigator !== 'undefined' && /Chrome\//.test(navigator.userAgent) && !/Firefox|FxiOS/.test(navigator.userAgent);
  lgMap(w, h, bezel) {
    const key = w + 'x' + h + 'b' + bezel;
    if (this.lgCache[key]) return this.lgCache[key];
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const ctx = c.getContext('2d'), img = ctx.createImageData(w, h), d = img.data;
    const r = h / 2, hx = w / 2, hy = h / 2;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const px = x + 0.5 - hx, py = y + 0.5 - hy;
      const qx = Math.abs(px) - (hx - r), qy = Math.abs(py) - (hy - r);
      const ox = Math.max(qx, 0), oy = Math.max(qy, 0), out = Math.hypot(ox, oy);
      const dist = -(out + Math.min(Math.max(qx, qy), 0) - r);
      let nx = 0, ny = 0;
      if (qx > 0 && qy > 0) { nx = ox / (out || 1); ny = oy / (out || 1); } else if (qx > qy) nx = 1; else ny = 1;
      nx *= px < 0 ? -1 : 1; ny *= py < 0 ? -1 : 1;
      let m = 0;
      if (dist >= 0 && dist < bezel) { const t = 1 - dist / bezel; m = 1 - Math.sqrt(1 - t * t); }
      const i = (y * w + x) * 4;
      d[i] = 128 - nx * m * 127; d[i + 1] = 128 - ny * m * 127; d[i + 2] = 128; d[i + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    return (this.lgCache[key] = c.toDataURL());
  }
  lgFilter(id, w, h, bezel, scale, blur) {
    return '<filter id="' + id + '" color-interpolation-filters="sRGB" filterUnits="userSpaceOnUse" primitiveUnits="userSpaceOnUse" x="0" y="0" width="' + w + '" height="' + h + '">' +
      '<feImage href="' + this.lgMap(w, h, bezel) + '" x="0" y="0" width="' + w + '" height="' + h + '" preserveAspectRatio="none" result="map"></feImage>' +
      '<feGaussianBlur in="SourceGraphic" stdDeviation="' + blur + '" result="b"></feGaussianBlur>' +
      '<feDisplacementMap in="b" in2="map" scale="' + scale + '" xChannelSelector="R" yChannelSelector="G"></feDisplacementMap></filter>';
  }
  buildGlass = () => {
    const nav = this.navRef.current, rects = this.state.rects;
    if (!this.lgSvg && this.lgOK) {
      const sv = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      sv.setAttribute('aria-hidden', 'true'); sv.setAttribute('width', '0'); sv.setAttribute('height', '0');
      sv.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none;';
      document.body.appendChild(sv); this.lgSvg = sv;
    }
    const svg = this.lgSvg;
    if (!this.lgOK || !svg || !nav || !rects) return;
    const tw = Math.round(nav.offsetWidth), th = Math.round(nav.offsetHeight), lh = th - 8;
    let html = this.lgFilter('lgTrack', tw, th, Math.min(32, th / 2), 32, 2);
    rects.forEach((r, i) => { html += this.lgFilter('lgLens' + i, Math.round(r.w), lh, Math.min(18, lh / 2), 26, 0.6); });
    svg.innerHTML = '<defs>' + html + '</defs>';
    nav.style.backdropFilter = 'url(#lgTrack) saturate(1.4) brightness(1.05)';
    this.applyLens();
  };
  applyLens = () => {
    const lens = this.lensRef.current;
    if (!this.lgOK || !lens || !this.state.rects) return;
    const i = this.state.hover ?? this.state.active ?? 0;
    lens.style.backdropFilter = 'url(#lgLens' + i + ') saturate(1.5) brightness(1.12)';
  };
  linkRefs = [0,1,2,3,4].map(() => React.createRef());
  measureNav = () => {
    const nav = this.navRef.current; if (!nav) return;
    const nb = nav.getBoundingClientRect();
    const rects = this.linkRefs.map(r => { const el = r.current; if (!el) return null; const b = el.getBoundingClientRect(); return { x: b.left - nb.left - nav.clientLeft, w: b.width }; });
    if (rects.every(Boolean)) this.setState({ rects });
  };
  goLensBack = () => {
    if (this.state.pressed) this.setState({ pressed: false });
    if (this.state.hover == null || this.state.hover === this.state.active) { this.setState({ hover: null }); return; }
    clearTimeout(this.squishT);
    this.setState({ hover: null, squish: true });
    this.squishT = setTimeout(() => this.setState({ squish: false }), 340);
  };
  goLens = i => {
    const cur = this.state.hover ?? this.state.active;
    if (i === cur) return;
    clearTimeout(this.squishT);
    this.setState({ hover: i, squish: true });
    this.squishT = setTimeout(() => this.setState({ squish: false }), 340);
  };
  spotRef = React.createRef();
  spotMaskRef = React.createRef();
  spotGlowRef = React.createRef();
  spot = { x: 476, y: 300, tx: 476, ty: 300, init: false };
  onGridMove = e => {
    const svg = this.svgRef.current;
    if (!svg || this.props.gridHover === false) return;
    const m = svg.getScreenCTM(); if (!m) return;
    const p = new DOMPoint(e.clientX, e.clientY).matrixTransform(m.inverse());
    this.spot.tx = p.x; this.spot.ty = p.y;
    if (!this.spot.init) { this.spot.x = p.x; this.spot.y = p.y; this.spot.init = true; }
    if (this.spotRef.current) this.spotRef.current.style.opacity = '1';
  };
  onGridLeave = () => { if (this.spotRef.current) this.spotRef.current.style.opacity = '0'; this.spot.init = false; };
  wp = { amt: 0, px: null, py: null, vx: 0, vy: 0, dx: 0, dy: 0, ux: 0, uy: 0, idle: true };
  warpTick() {
    const svg = this.svgRef.current; if (!svg) return;
    const w = this.wp, sp = this.spot, on = !!sp.init && this.props.gridHover !== false && !(this.rm && this.rm.matches);
    w.amt += ((on ? 1 : 0) - w.amt) * 0.06;
    if (w.px === null || !on) { w.px = sp.x; w.py = sp.y; }
    const mvx = sp.x - w.px, mvy = sp.y - w.py; w.px = sp.x; w.py = sp.y;
    w.vx += (mvx - w.vx) * 0.35; w.vy += (mvy - w.vy) * 0.35;
    const G = 3.6, E = 0.16;
    w.dx += (w.vx * G - w.dx) * E; w.dy += (w.vy * G - w.dy) * E;
    const lim = 56, m = Math.hypot(w.dx, w.dy); if (m > lim) { w.dx *= lim / m; w.dy *= lim / m; }
    const active = w.amt > 0.003 || Math.abs(w.dx) + Math.abs(w.dy) > 0.05;
    if (!active && w.idle) return;
    if (!this.wEls || !this.wEls[0] || !this.wEls[0].isConnected) this.wEls = [...svg.querySelectorAll('[data-w]')].map(el => ({ el, t: el.dataset.w, x: +el.dataset.x, y: +el.dataset.y, a: +el.dataset.a, b: +el.dataset.b }));
    const cx = sp.x, cy = sp.y, S2 = 2 * 165 * 165, B = 0.18 * w.amt, dx = w.dx, dy = w.dy, R2 = 520 * 520;
    const off = (x, y) => { const ex = x - cx, ey = y - cy, r2 = ex * ex + ey * ey; if (r2 > R2) return null; const g = Math.exp(-r2 / S2); return [g * (dx + ex * B), g * (dy + ey * B)]; };
    for (const it of this.wEls) {
      if (it.t === 'd') { const o = active && off(it.x, it.y); it.el.setAttribute('cx', o ? (it.x + o[0]).toFixed(1) : it.x); it.el.setAttribute('cy', o ? (it.y + o[1]).toFixed(1) : it.y); continue; }
      const vert = it.t === 'v', fixed = vert ? it.x : it.y;
      if (!active || (vert ? Math.abs(fixed - cx) : Math.abs(fixed - cy)) > 520) { it.el.setAttribute('d', vert ? 'M' + fixed + ' ' + it.a + 'V' + it.b : 'M' + it.a + ' ' + fixed + 'H' + it.b); continue; }
      const c = vert ? cy : cx, lo = Math.max(it.a, c - 520), hi = Math.min(it.b, c + 520);
      let d = vert ? 'M' + fixed + ' ' + it.a + 'V' + lo.toFixed(0) : 'M' + it.a + ' ' + fixed + 'H' + lo.toFixed(0);
      for (let t = lo; t <= hi + 0.1; t += 22) { const x = vert ? fixed : t, y = vert ? t : fixed, o = off(x, y) || [0, 0]; d += 'L' + (x + o[0]).toFixed(1) + ' ' + (y + o[1]).toFixed(1); }
      d += vert ? 'V' + it.b : 'H' + it.b;
      it.el.setAttribute('d', d);
    }
    w.idle = !active;
  }
  geo = { N: 231, CX: 476, CY: 633, R: 453, A: 68 * Math.PI / 180 };
  base = this.makeBase();

  makeBase() {
    const { N, A } = this.geo;
    const hash = i => { const s = Math.sin(i * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
    const out = [];
    for (let i = 0; i < N; i++) {
      const th = -A + 2 * A * (i / (N - 1));
      const n = Math.sin(i * 0.31 + 0.4) * 0.5 + Math.sin(i * 0.117 + 1.7) * 0.35 + Math.sin(i * 0.043 + 2.6) * 0.15;
      const c = Math.max(0, 0.5 + 0.5 * n);
      const e = Math.abs(th) / A;
      const len = (4 + 36 * Math.pow(c, 1.6) * (0.45 + 0.55 * hash(i))) * (1 - 0.35 * e * e);
      const f = Math.min(1, Math.max(0, (e - 0.68) / 0.32));
      const op = 0.85 * (1 - f * f * (3 - 2 * f)) + 0.03;
      out.push({ sin: Math.sin(th), cos: Math.cos(th), len, op: +op.toFixed(3), ph: hash(i + 99) * 6.283 });
    }
    return out;
  }

  coords(b, L) {
    const { CX, CY, R } = this.geo;
    const a = R - L / 2, z = R + L / 2;
    return { x1: CX + a * b.sin, y1: CY - a * b.cos, x2: CX + z * b.sin, y2: CY - z * b.cos };
  }

  soonRef = React.createRef();
  soonCopy = {
    signup: ['Sign-up is on its way', 'Accounts and the AutoDub dashboard are being built. Check back soon to start dubbing your videos.'],
    sample: ['Samples are on their way', 'We are preparing dubbed audio samples so you can hear AutoDub in every language.'],
    checkout: ['Checkout is on its way', 'Plans and billing are being set up. You will be able to pick a plan here soon.'],
    sales: ['Sales contact is on its way', 'Our sales page is being set up. Until then, write to hello@autodub.ai.'],
    social: ['Our channels are on their way', 'AutoDub social channels launch soon.']
  };
  onSoonClick = e => {
    const a = e.target.closest && e.target.closest('[data-soon]'); if (!a) return;
    e.preventDefault();
    this.setState({ soon: a.getAttribute('data-soon'), menuOpen: false });
  };
  onSoonKey = e => { if (e.key === 'Escape' && this.state.soon) this.setState({ soon: null }); };
  componentDidMount() {
    // Server render assumes desktop; switch to the mobile tree before any setup runs.
    const w = window.innerWidth, m = w < 760, t = this.tiersFor(w), s = this.state;
    if (m !== s.mobile || t.compact !== s.compact || t.ucS !== s.ucS || t.prS !== s.prS) this.setState({ mobile: m, ...t }, () => this.init());
    else this.init();
  }

  init() {
    document.addEventListener('click', this.onSoonClick);
    document.addEventListener('keydown', this.onSoonKey);
    this.onResize = () => {
      const w = window.innerWidth, m = w < 760, t = this.tiersFor(w), s = this.state;
      if (m !== s.mobile || t.compact !== s.compact || t.ucS !== s.ucS || t.prS !== s.prS) this.setState({ mobile: m, ...t, menuOpen: false });
    };
    window.addEventListener('resize', this.onResize);
    this.mq = window.matchMedia ? window.matchMedia('(max-width: 759px)') : null;
    if (this.mq) this.mq.addEventListener('change', this.onResize);
    this.onResize();
    requestAnimationFrame(this.onResize);
    this.onNavResize = () => this.measureNav();
    window.addEventListener('resize', this.onNavResize);
    requestAnimationFrame(this.measureNav);
    window.addEventListener('resize', this.sbLayout);
    requestAnimationFrame(this.sbLayout);
    if (this.sbRO && this.sbRef.current) { this.sbRO.observe(this.sbRef.current); this.sbObs = true; }
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => this.sbLayout());
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => this.measureNav());
    this.rm = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
    this.runPreloader();
    this.setupReveal();
    this.setupFx();
    this.setupHow();
    this.setupUc();
    this.setupPr();
    this.setupFaq();
    if (typeof IntersectionObserver !== 'undefined') {
      this.vis = { hero: true, card: true };
      const sec = this.svgRef.current && this.svgRef.current.closest('section'), card = this.videoInRef.current;
      this.visIO = new IntersectionObserver(es => es.forEach(en => { if (en.target === sec) this.vis.hero = en.isIntersecting; if (en.target === card) this.vis.card = en.isIntersecting; }), { rootMargin: '100px' });
      if (sec) this.visIO.observe(sec); if (card) this.visIO.observe(card);
    }
    this.startTrustFx(this.props.preloader === false ? 800 : 4200);

    this.cbLayout(); requestAnimationFrame(this.cbLayout); window.addEventListener('resize', this.cbLayout);
    if (typeof ResizeObserver !== 'undefined' && this.videoInRef.current) { this.cbRO = new ResizeObserver(() => this.cbLayout()); this.cbRO.observe(this.videoInRef.current); }
    const tick = now => {
      this.raf = requestAnimationFrame(tick);
      const sp = this.spot, k = (this.rm && this.rm.matches) ? 1 : 0.32;
      sp.x += (sp.tx - sp.x) * k; sp.y += (sp.ty - sp.y) * k;
      if (this.vis && !this.vis.hero) return;
      const tt = this.tkTrackRef.current, tg = this.tkGroupRef.current;
      if (tt && tg && !(this.rm && this.rm.matches)) {
        if (!this.tkW || (now - (this.tkWt || 0)) > 2000) { this.tkW = tg.offsetWidth; this.tkWt = now; }
        const tw = this.tkW;
        if (tw) tt.style.transform = 'translate3d(' + (-(((now / 1000) * 42) % tw)).toFixed(2) + 'px,0,0)';
      }
      if (!this.vis || this.vis.card) this.cbTick(now);
      this.warpTick();
      const sb = this.sb, sv = this.sbSvgRef.current;
      if (sv && sb.w) {
        if (!sb.on && !(this.rm && this.rm.matches)) {
          const P = 2 * (sb.w - sb.h) + Math.PI * sb.h, r = sb.h / 2, L = sb.w - sb.h;
          let d = ((now / 1000) * 150) % P;
          if (d < L) { sb.tx = 24 + r + d; sb.ty = 24; }
          else if ((d -= L) < Math.PI * r) { const a = -Math.PI / 2 + d / r; sb.tx = 24 + r + L + Math.cos(a) * r; sb.ty = 24 + r + Math.sin(a) * r; }
          else if ((d -= Math.PI * r) < L) { sb.tx = 24 + r + L - d; sb.ty = 24 + sb.h; }
          else { d -= L; const a = Math.PI / 2 + d / r; sb.tx = 24 + r + Math.cos(a) * r; sb.ty = 24 + r + Math.sin(a) * r; }
        }
        const kk = (this.rm && this.rm.matches) ? 1 : (sb.on ? 0.14 : 0.16);
        sb.x += (sb.tx - sb.x) * kk; sb.y += (sb.ty - sb.y) * kk;
        if (!this.sbG) this.sbG = [sv.querySelector('#sbEdge'), sv.querySelector('#sbGlow')];
        this.sbG.forEach(g => { if (g) { g.setAttribute('cx', sb.x.toFixed(1)); g.setAttribute('cy', sb.y.toFixed(1)); } });
      }
      const mc = this.spotMaskRef.current, gc = this.spotGlowRef.current;
      if (Math.abs(sp.x - (sp.lx ?? -1e9)) + Math.abs(sp.y - (sp.ly ?? -1e9)) > 0.15) {
        sp.lx = sp.x; sp.ly = sp.y;
        if (mc) { mc.setAttribute('cx', sp.x.toFixed(1)); mc.setAttribute('cy', sp.y.toFixed(1)); }
        if (gc) { gc.setAttribute('cx', sp.x.toFixed(1)); gc.setAttribute('cy', sp.y.toFixed(1)); }
      }
      const g = this.waveRef.current;
      if (!g || this.props.animate === false || (this.rm && this.rm.matches)) return;
      if (!this.waveLines || this.waveLines.length !== this.base.length) this.waveLines = g.querySelectorAll('line');
      const lines = this.waveLines;
      const t = (now / 1000) * (this.props.waveSpeed ?? 1);
      const amp = this.props.waveAmplitude ?? 1;
      for (let i = 0; i < lines.length && i < this.base.length; i++) {
        const b = this.base[i];
        const m = 0.78 + 0.16 * Math.sin(t * 1.5 - i * 0.12) + 0.1 * Math.sin(t * 0.83 + i * 0.051 + 1.3) + 0.05 * Math.sin(t * 2.3 + b.ph);
        const c = this.coords(b, Math.max(2, b.len * amp * m));
        const el = lines[i];
        el.setAttribute('x1', c.x1.toFixed(2)); el.setAttribute('y1', c.y1.toFixed(2));
        el.setAttribute('x2', c.x2.toFixed(2)); el.setAttribute('y2', c.y2.toFixed(2));
      }
    };
    this.raf = requestAnimationFrame(tick);
  }

  componentDidUpdate() {
    const st = this.state, lp = this._lp || {};
    if ((lp.soon || null) !== (st.soon || null)) {
      document.documentElement.style.overflow = st.soon ? 'hidden' : '';
      const el = this.soonRef.current;
      if (st.soon && el) { el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 320, easing: 'ease-out' }); const b = el.querySelector('button'); if (b) b.focus({ preventScroll: true }); }
    }
    if (lp.rects !== st.rects) this.buildGlass();
    else if (lp.hover !== st.hover || lp.active !== st.active) this.applyLens();
    if (lp.mobile !== undefined && lp.mobile !== st.mobile && !st.mobile) requestAnimationFrame(this.measureNav);
    if (lp.compact !== undefined && lp.compact !== st.compact && !st.compact) requestAnimationFrame(this.measureNav);
    if (this.ucShown && lp.ucS !== undefined && lp.ucS !== st.ucS) this.ucApply(true);
    this._lp = { soon: st.soon || null, rects: st.rects, hover: st.hover, active: st.active, mobile: st.mobile, compact: st.compact, ucS: st.ucS };
  }

  componentWillUnmount() {
    clearTimeout(this.preT);
    document.documentElement.style.overflow = '';
    document.removeEventListener('click', this.onSoonClick);
    document.removeEventListener('keydown', this.onSoonKey);
    if (this.visIO) this.visIO.disconnect();
    if (this.rvIO) this.rvIO.disconnect();
    if (this.fxIO) this.fxIO.disconnect();
    if (this.hwIO) this.hwIO.disconnect();
    if (this.fqCheck) { window.removeEventListener('scroll', this.fqCheck); window.removeEventListener('resize', this.fqCheck); }
    if (this.prCheck) { window.removeEventListener('scroll', this.prCheck); window.removeEventListener('resize', this.prCheck); }
    if (this.ucCheck) { window.removeEventListener('scroll', this.ucCheck); window.removeEventListener('resize', this.ucCheck); }
    if (this.ucMove && this.ucRef.current) { this.ucRef.current.removeEventListener('mousemove', this.ucMove); this.ucRef.current.removeEventListener('mouseleave', this.ucLeave); }
    if (this.hwRaf) cancelAnimationFrame(this.hwRaf);
    if (this.hwMeasure) window.removeEventListener('resize', this.hwMeasure);
    if (this.hwKick) window.removeEventListener('scroll', this.hwKick);
    if (this.fxRaf) cancelAnimationFrame(this.fxRaf);
    clearTimeout(this.trustT);
    window.removeEventListener('wheel', this.onWheel);
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('resize', this.onNavResize);
    window.removeEventListener('resize', this.sbLayout);
    if (this.lgSvg) this.lgSvg.remove();
    clearTimeout(this.squishT);
    if (this.mq) this.mq.removeEventListener('change', this.onResize);
  }

  renderVals() {
    const amp = this.props.waveAmplitude ?? 1;
    const bars = this.base.map(b => ({ ...this.coords(b, Math.max(2, b.len * amp * 0.9)), op: b.op }));
    const gridV = [];
    for (let k = -6; k <= 9; k++) gridV.push(181 + 197 * k);
    const mobile = this.state.mobile;
    const act = this.state.active ?? 0, tgt = this.state.hover ?? act;
    const rc = this.state.rects && this.state.rects[tgt];
    const navVals = { navRef: this.navRef, navLeave: () => this.goLensBack(), lensX: rc ? rc.x : 0, lensW: rc ? rc.w : 0, lensOp: rc ? 1 : 0, lensSX: this.state.pressed ? 0.93 : this.state.squish ? 1.08 : 1, lensSY: this.state.pressed ? 0.88 : this.state.squish ? 0.92 : 1, pressOp: this.state.pressed ? 1 : 0, lensTrans: this.state.pressed ? 'transform 160ms cubic-bezier(.3,.7,.4,1), width 820ms cubic-bezier(.22,1.22,.36,1), opacity 300ms ease' : 'transform 820ms cubic-bezier(.22,1.22,.36,1), width 820ms cubic-bezier(.22,1.22,.36,1), opacity 300ms ease', pu: () => this.state.pressed && this.setState({ pressed: false }) };
    this.linkRefs.forEach((r, i) => {
      navVals['linkRef' + i] = r;
      navVals['hv' + i] = () => this.goLens(i);
      navVals['ck' + i] = e => { e.preventDefault(); this.setState({ active: i, hover: i, pressed: false }); this.goSec(i); };
      navVals['mk' + i] = e => { e.preventDefault(); this.setState({ active: i, menuOpen: false }); this.goSec(i); };
      navVals['pd' + i] = () => { clearTimeout(this.squishT); this.setState({ hover: i, pressed: true, squish: false }); };
      navVals['col' + i] = i === tgt ? '#ffffff' : '#a9adbb';
      navVals['cur' + i] = i === act ? 'page' : undefined;
    });
    return {
      ...navVals, probRef: this.probRef, howRef: this.howRef, howTrackRef: this.howTrackRef, tkTrackRef: this.tkTrackRef, tkGroupRef: this.tkGroupRef, lensRef: this.lensRef, trustRef: this.trustRef, cbSvgRef: this.cbSvgRef, preRef: this.preRef, preTopRef: this.preTopRef, preBotRef: this.preBotRef, preLogoRef: this.preLogoRef, headerRef: this.headerRef, heroInRef: this.heroInRef, videoInRef: this.videoInRef, sbRef: this.sbRef, sbSvgRef: this.sbSvgRef, sbMove: this.sbMove, sbLeave: this.sbLeave,
      bars, gridV, waveRef: this.waveRef, svgRef: this.svgRef,
      hwLogo: [[85, 96, 129], [110, 90, 134], [135, 54, 144], [160, 46, 154], [185, 59, 168], [210, 81, 166], [235, 64, 136], [260, 94, 129]].map(([x, a, b], i) => ({ x, y1: a, y2: b, m: (a + b) / 2, l: b - a, i })),
      hwSide: [-1, 1].flatMap(s => Array.from({ length: 44 }, (_, k) => { const d = k + 1, x = s < 0 ? 60 - 25 * d : 287 + 25 * d, j = k * 1.37 + (s > 0 ? 2.1 : 0); const l = 10 + 44 * Math.abs(Math.sin(j) * Math.sin(j * 0.41 + 0.7)) * (0.55 + 0.45 * Math.exp(-d / 14)) + 10 * Math.exp(-d / 3); return { x, m: 112, l: +l.toFixed(1), y1: (112 - l / 2).toFixed(1), y2: (112 + l / 2).toFixed(1), op: Math.max(0.1, 0.62 * Math.exp(-d / 11)).toFixed(3), i: 8 + d * (s < 0 ? 1 : 1.3) }; })),
      onGridMove: this.onGridMove, onGridLeave: this.onGridLeave,
      spotRef: this.spotRef, spotMaskRef: this.spotMaskRef, spotGlowRef: this.spotGlowRef,
      gridH: [-49, 148, 345, 541, 738, 935],
      gridVB: gridV.map(x => ({ x, d: 'M' + x + ' 0V687' })),
      gridVL: gridV.map(x => ({ x, d: 'M' + x + ' -200V1087' })),
      gridHL: [-49, 148, 345, 541, 738, 935].map(y => ({ y, d: 'M-952 ' + y + 'H1904' })),
      gridDots: gridV.flatMap(x => [-49, 148, 345, 541, 738, 935].map(y => ({ x, y }))),
      gridDisplay: this.props.showGrid === false ? 'none' : 'inline',
      isDesktop: !mobile, isMobile: mobile, soonRef: this.soonRef, soonOpen: !!this.state.soon, soonTitle: (this.soonCopy[this.state.soon] || [])[0], soonText: (this.soonCopy[this.state.soon] || [])[1], soonClose: () => this.setState({ soon: null }), heroMinH: mobile ? 'auto' : '100svh', ftAlign: mobile ? 'flex-start' : 'flex-end', ftText: mobile ? 'left' : 'right', ftGap: mobile ? '36px' : '32px', ftNavDir: mobile ? 'row' : 'column', ftNavWrap: mobile ? 'wrap' : 'nowrap', ftNavGap: mobile ? '12px 22px' : 'clamp(10px, 1cqw, 16px)', cardAR: mobile ? '3 / 2' : '16 / 9', heroPadB: mobile ? '150px' : 'clamp(116px, calc(22svh - 14px), 246px)', heroPadT: mobile ? '116px' : 'clamp(86px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.1113 + 14px), 134px)', navFull: !this.state.compact, navCompact: !!this.state.compact, ucDesk: !this.state.ucS, ucStack: !!this.state.ucS, ucRef: this.ucRef, faqRef: this.faqRef,
      faqItems: [
        ['How natural do the dubbed voices sound?', "Each speaker's voice is cloned from the original audio, so tone, timbre and emotion carry over. Most viewers can't tell the dub from a native recording."],
        ['Which languages does AutoDub support?', 'More than 130 languages and regional accents, including Spanish, Hindi, Portuguese, Japanese, Arabic and French. New languages are added every month.'],
        ['Will my background music and effects be kept?', 'Yes. AutoDub separates dialogue from music, ambience and sound effects, then remixes the new voice over the original soundtrack.'],
        ['Can I review and edit translations before publishing?', 'Every line is editable in the transcript editor. Change wording, adjust timing or regenerate a single line without re-dubbing the whole video.'],
        ['Who owns the dubbed content?', 'You do. Your videos, voices and dubbed outputs are yours, are never used to train public models, and can be deleted at any time.']
      ].map(([q, a], i) => {
        const open = (this.state.faqOpen ?? 0) === i;
        return { q, a, d: i + 1, exp: open ? 'true' : 'false', rows: open ? '1fr' : '0fr', rot: open ? 45 : 0, glow: open ? 1 : 0,
          bg: open ? 'radial-gradient(75% 42% at 50% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)' : 'linear-gradient(165deg, rgba(28,32,54,0.8) 0%, rgba(16,18,34,0.9) 50%, rgba(11,13,26,0.95) 100%)',
          edge: open ? 'linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)' : 'linear-gradient(180deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.04) 50%, rgba(130,110,255,0.22) 100%)',
          toggle: () => this.setState(s => ({ faqOpen: (s.faqOpen ?? 0) === i ? -1 : i })) };
      }),
      ...(() => {
        const t = this.state.prTab ?? 0, P = [[19, 49, 149], [17, 44, 134], [15, 39, 119]][t], M = [60, 300, 1200];
        const o = { prRef: this.prRef, prDir: this.state.prS ? 'column' : 'row', prAlign: this.state.prS ? 'center' : 'stretch', prBill: ['Billed monthly', 'Billed quarterly', 'Billed yearly'][t],
          prMaskL: this.state.prS ? 'none' : 'linear-gradient(90deg, rgba(0,0,0,0.3) 0%, #000 78%)', prMaskR: this.state.prS ? 'none' : 'linear-gradient(270deg, rgba(0,0,0,0.3) 0%, #000 78%)',
          prRows0: [{ k: 'Dubbing minutes', v: '60 / mo' }, { k: 'Languages', v: '30' }, { k: 'Voice cloning', v: 'Standard' }, { k: 'Lip sync', v: '—' }, { k: 'Speakers per video', v: '2' }, { k: 'Watermark-free', v: '—' }],
          prRows1: [{ k: 'Dubbing minutes', v: '300 / mo' }, { k: 'Languages', v: '130+' }, { k: 'Voice cloning', v: 'Studio-grade' }, { k: 'Lip sync', v: 'Included' }, { k: 'Speakers per video', v: '6' }, { k: 'Watermark-free', v: 'Included' }],
          prRows2: [{ k: 'Dubbing minutes', v: '1,200 / mo' }, { k: 'Languages', v: '130+' }, { k: 'Voice cloning', v: 'Studio-grade' }, { k: 'Lip sync', v: 'Included' }, { k: 'Speakers per video', v: 'Unlimited' }, { k: 'Watermark-free', v: 'Included' }],
          prOpt0: [{ k: 'Team seats', v: '1' }, { k: 'Priority rendering', v: '—' }, { k: 'API access', v: '—' }],
          prOpt1: [{ k: 'Team seats', v: '3' }, { k: 'Priority rendering', v: 'Included' }, { k: 'API access', v: '—' }],
          prOpt2: [{ k: 'Team seats', v: '10' }, { k: 'Priority rendering', v: 'Included' }, { k: 'API access', v: 'Included' }] };
        [0, 1, 2].forEach(i => {
          o['pr' + i] = { price: P[i], per: (P[i] / M[i]).toFixed(2) };
          o['prSel' + i] = t === i ? 'true' : 'false';
          o['prPick' + i] = () => this.setState({ prTab: i });
          o['prTabBg' + i] = t === i ? 'radial-gradient(36% 46% at 50% 112%, rgba(140,235,255,0.75) 0%, rgba(140,235,255,0) 100%) padding-box, radial-gradient(75% 105% at 50% 125%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.50) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%) padding-box, linear-gradient(165deg, #1b1f38 0%, #12152a 55%, #0d1022 100%) padding-box, linear-gradient(180deg, rgba(255,255,255,0.32) 0%, rgba(255,255,255,0.06) 38%, rgba(130,110,255,0.6) 78%, rgba(150,235,255,0.95) 100%) border-box' : 'transparent';
          o['prTabC' + i] = t === i ? '#ffffff' : '#a9b0c4';
          o['prTabSh' + i] = t === i ? '0 10px 28px -12px rgba(72,96,255,0.6), 0 6px 20px -10px rgba(140,235,255,0.35)' : 'none';
        });
        return o;
      })(),
      ucCases: [
        { title: 'YouTube & Independent Creators', desc: "Publish every upload in new languages without re-recording a word, and grow audiences you couldn't reach before.", d: 'M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5zM10 9l5 3-5 3z', rot: -2 },
        { title: 'Education & Online Learning', desc: 'Turn one course into many. Lessons sound native, so learners focus on the material, not the accent.', d: 'M3 9l9-4 9 4-9 4zM7 11v4.5c1.5 1.3 3.2 2 5 2s3.5-.7 5-2V11M21 9v5', rot: 2 },
        { title: 'Podcasts & Interviews', desc: 'Every host and guest keeps their own voice, so conversations stay natural in every language.', d: 'M12 3a3 3 0 0 1 3 3v5a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3zM5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21', rot: -1.5 },
        { title: 'Documentaries & Media Production', desc: 'Broadcast-ready dubs with timing and emotion matched to the cut, at a fraction of studio cost.', d: 'M4 5h16v14H4zM8 5v14M16 5v14M4 9.5h4M4 14.5h4M16 9.5h4M16 14.5h4', rot: 2 },
        { title: 'Businesses & Corporate Training', desc: 'Roll out onboarding and training to global teams in days, with one consistent, on-brand voice.', d: 'M4 8h16v11H4zM9 8V5.5h6V8M4 13h16', rot: -2 }
      ],
      showMenu: !!this.state.compact && this.state.menuOpen,
      menuExpanded: this.state.menuOpen ? 'true' : 'false',
      toggleMenu: () => this.setState(s => ({ menuOpen: !s.menuOpen })),
    };
  }

  render() {
    const v = this.renderVals();
    return (
      <>
      {" "}
      <div ref={v.preRef} aria-hidden="true" style={{ position: "fixed", top: "0", left: "0", width: "100vw", height: "100svh", zIndex: "1000" }}>
        {" "}
        <div ref={v.preTopRef} style={{ position: "absolute", left: "0", right: "0", top: "0", height: "calc(50% + 1px)", background: "#080913" }} />
        {" "}
        <div ref={v.preBotRef} style={{ position: "absolute", left: "0", right: "0", bottom: "0", height: "50%", background: "#080913" }} />
        {" "}
        <div style={{ position: "absolute", inset: "0", display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none" }}>
          {" "}
          <svg ref={v.preLogoRef} focusable="false" viewBox="48 36 252 142" style={{ height: "clamp(36px, 4.4vw, 52px)", width: "auto", display: "block", overflow: "visible", filter: "drop-shadow(0 0 22px rgba(72,96,255,0.45))" }} fill="#ffffff" stroke="#ffffff" strokeWidth="11" strokeLinecap="round">
            <circle cx="60" cy="112" r="6.5" stroke="none" />
            <line x1="85" y1="96" x2="85" y2="129" />
            <line x1="110" y1="90" x2="110" y2="134" />
            <line x1="135" y1="54" x2="135" y2="144" />
            <line x1="160" y1="46" x2="160" y2="154" />
            <line x1="185" y1="59" x2="185" y2="168" />
            <line x1="210" y1="81" x2="210" y2="166" />
            <line x1="235" y1="64" x2="235" y2="136" />
            <line x1="260" y1="94" x2="260" y2="129" />
            <circle cx="287" cy="112" r="6.5" stroke="none" />
          </svg>
          {" "}
        </div>
        {" "}
      </div>
      {" "}
      <div style={{ containerType: "inline-size", width: "100%", background: "#080913", fontFamily: "'Geist','Helvetica Neue',Helvetica,Arial,sans-serif", color: "#e6e9f2", WebkitFontSmoothing: "antialiased" }}>
        {" "}
        <section data-screen-label="Hero" onMouseMove={v.onGridMove} onMouseLeave={v.onGridLeave} style={{ position: "relative", overflow: "hidden", minHeight: v.heroMinH, display: "flex", flexDirection: "column", justifyContent: "center", background: "#080913" }}>
          {" "}
          <header ref={v.headerRef} style={{ position: "absolute", top: "0", left: "0", right: "0", zIndex: "5", padding: "clamp(22px, 3.4svh, 36px) clamp(14px, 2.6cqw, 40px) 0", display: "flex", justifyContent: "center" }}>
            {" "}
            <div style={{ position: "relative", width: "100%", height: "clamp(56px, 7svh, 64px)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "16px", padding: "0 clamp(4px, 1.4cqw, 24px)" }}>
              {" "}
              <div style={{ display: "flex", alignItems: "center", gap: "clamp(12px, 1.6cqw, 22px)", minWidth: "0" }}>
                {" "}
                <a className="adp0" href="#" aria-label="AutoDub home" style={{ fontSize: "clamp(21px, 5.6cqw, 23px)", fontWeight: "600", letterSpacing: "-0.035em", color: "#ffffff", lineHeight: "1", borderRadius: "4px", display: "inline-flex", alignItems: "center", gap: "10px" }}>
                  <svg aria-hidden="true" focusable="false" viewBox="48 36 252 142" style={{ height: "clamp(25px, 6.8cqw, 28px)", width: "auto", display: "block" }} fill="#ffffff" stroke="#ffffff" strokeWidth="11" strokeLinecap="round">
                    <circle cx="60" cy="112" r="6.5" stroke="none" />
                    <line x1="85" y1="96" x2="85" y2="129" />
                    <line x1="110" y1="90" x2="110" y2="134" />
                    <line x1="135" y1="54" x2="135" y2="144" />
                    <line x1="160" y1="46" x2="160" y2="154" />
                    <line x1="185" y1="59" x2="185" y2="168" />
                    <line x1="210" y1="81" x2="210" y2="166" />
                    <line x1="235" y1="64" x2="235" y2="136" />
                    <line x1="260" y1="94" x2="260" y2="129" />
                    <circle cx="287" cy="112" r="6.5" stroke="none" />
                  </svg>
                  <span>
                    {"AutoDub"}
                  </span>
                </a>
                {" "}
                {v.navFull ? (
                  <>
                    {" "}
                    <nav aria-label="Primary" ref={v.navRef} onMouseLeave={v.navLeave} style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)", display: "flex", alignItems: "center", gap: "0", padding: "4px", borderRadius: "999px", fontSize: "14px", fontWeight: "500", letterSpacing: "-0.01em", background: "rgba(255,255,255,0.035)", backdropFilter: "blur(10px) saturate(1.4) brightness(1.05)", WebkitBackdropFilter: "blur(10px) saturate(1.4) brightness(1.05)", boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.09), inset 1.5px 1.5px 1px -0.5px rgba(255,255,255,0.42), inset -1.5px -1.5px 1px -0.5px rgba(255,255,255,0.16), inset 0 0 16px rgba(255,255,255,0.05), 0 10px 30px rgba(0,0,0,0.45)" }}>
                      {" "}
                      <span aria-hidden="true" ref={v.lensRef} style={{ position: "absolute", zIndex: "0", top: "4px", bottom: "4px", left: "0", width: `${v.lensW}px`, transform: `translateX(${v.lensX}px) scale(${v.lensSX}, ${v.lensSY})`, opacity: v.lensOp, borderRadius: "999px", background: "rgba(255,255,255,0.055)", backdropFilter: "blur(4px) saturate(1.5) brightness(1.12)", WebkitBackdropFilter: "blur(4px) saturate(1.5) brightness(1.12)", boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.14), inset 1.5px 1.5px 1px -0.5px rgba(255,255,255,0.7), inset -1.5px -1.5px 1px -0.5px rgba(255,255,255,0.3), inset 0 0 10px rgba(255,255,255,0.08), 0 4px 14px rgba(0,0,0,0.5)", transition: v.lensTrans, willChange: "transform, width", pointerEvents: "none" }}>
                        <span style={{ position: "absolute", inset: "0", borderRadius: "999px", background: "radial-gradient(120% 140% at 50% 30%, rgba(255,255,255,0.22), rgba(255,255,255,0.04) 60%, rgba(255,255,255,0) 100%)", boxShadow: "inset 0 0 14px rgba(255,255,255,0.18)", opacity: v.pressOp, transition: "opacity 380ms ease" }} />
                      </span>
                      {" "}
                      <a href="#" ref={v.linkRef0} aria-current={v.cur0} onMouseEnter={v.hv0} onFocus={v.hv0} onClick={v.ck0} onMouseDown={v.pd0} onMouseUp={v.pu} onTouchStart={v.pd0} onTouchEnd={v.pu} style={{ position: "relative", zIndex: "1", display: "inline-flex", alignItems: "center", height: "40px", padding: "0 16px", borderRadius: "999px", color: v.col0, whiteSpace: "nowrap", transition: "color 260ms ease", outline: "none" }}>
                        {"Home"}
                      </a>
                      {" "}
                      <a href="#features" ref={v.linkRef1} aria-current={v.cur1} onMouseEnter={v.hv1} onFocus={v.hv1} onClick={v.ck1} onMouseDown={v.pd1} onMouseUp={v.pu} onTouchStart={v.pd1} onTouchEnd={v.pu} style={{ position: "relative", zIndex: "1", display: "inline-flex", alignItems: "center", height: "40px", padding: "0 16px", borderRadius: "999px", color: v.col1, whiteSpace: "nowrap", transition: "color 260ms ease", outline: "none" }}>
                        {"Features"}
                      </a>
                      {" "}
                      <a href="#how-it-works" ref={v.linkRef2} aria-current={v.cur2} onMouseEnter={v.hv2} onFocus={v.hv2} onClick={v.ck2} onMouseDown={v.pd2} onMouseUp={v.pu} onTouchStart={v.pd2} onTouchEnd={v.pu} style={{ position: "relative", zIndex: "1", display: "inline-flex", alignItems: "center", height: "40px", padding: "0 16px", borderRadius: "999px", color: v.col2, whiteSpace: "nowrap", transition: "color 260ms ease", outline: "none" }}>
                        {"How it works"}
                      </a>
                      {" "}
                      <a href="#use-cases" ref={v.linkRef3} aria-current={v.cur3} onMouseEnter={v.hv3} onFocus={v.hv3} onClick={v.ck3} onMouseDown={v.pd3} onMouseUp={v.pu} onTouchStart={v.pd3} onTouchEnd={v.pu} style={{ position: "relative", zIndex: "1", display: "inline-flex", alignItems: "center", height: "40px", padding: "0 16px", borderRadius: "999px", color: v.col3, whiteSpace: "nowrap", transition: "color 260ms ease", outline: "none" }}>
                        {"Use Cases"}
                      </a>
                      {" "}
                      <a href="#pricing" ref={v.linkRef4} aria-current={v.cur4} onMouseEnter={v.hv4} onFocus={v.hv4} onClick={v.ck4} onMouseDown={v.pd4} onMouseUp={v.pu} onTouchStart={v.pd4} onTouchEnd={v.pu} style={{ position: "relative", zIndex: "1", display: "inline-flex", alignItems: "center", height: "40px", padding: "0 16px", borderRadius: "999px", color: v.col4, whiteSpace: "nowrap", transition: "color 260ms ease", outline: "none" }}>
                        {"Pricing"}
                      </a>
                      {" "}
                    </nav>
                    {" "}
                  </>
                ) : null}
                {" "}
              </div>
              {" "}
              {v.navFull ? (
                <>
                  {" "}
                  <a className="adp1 adp2" href="#" data-soon="signup" style={{ display: "inline-flex", alignItems: "center", height: "44px", padding: "0 20px", borderRadius: "999px", background: "#f4f7ff", color: "#0b1230", fontSize: "14px", fontWeight: "500", whiteSpace: "nowrap", letterSpacing: "-0.01em", boxShadow: "inset 0 -1px 0 rgba(11,18,48,0.12), 0 4px 16px rgba(0,0,0,0.25)", transition: "background 160ms ease" }}>
                    {"Try AutoDub"}
                  </a>
                  {" "}
                </>
              ) : null}
              {" "}
              {v.navCompact ? (
                <>
                  {" "}
                  <button className="adp3 adp2" type="button" aria-label="Menu" aria-expanded={v.menuExpanded} aria-controls="mobile-menu" onClick={v.toggleMenu} style={{ width: "44px", height: "44px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "5px", borderRadius: "999px", border: "0", background: "rgba(255,255,255,0.045)", backdropFilter: "blur(12px) saturate(1.4)", WebkitBackdropFilter: "blur(12px) saturate(1.4)", boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.12), inset 1.5px 1.5px 1px -0.5px rgba(255,255,255,0.4), inset -1.5px -1.5px 1px -0.5px rgba(255,255,255,0.14), 0 8px 24px rgba(0,0,0,0.35)", transition: "background 180ms ease", cursor: "pointer", padding: "0" }}>
                    {" "}
                    <span style={{ display: "block", width: "16px", height: "1.5px", background: "#e6e9f2", borderRadius: "2px" }} />
                    {" "}
                    <span style={{ display: "block", width: "16px", height: "1.5px", background: "#e6e9f2", borderRadius: "2px" }} />
                    {" "}
                  </button>
                  {" "}
                </>
              ) : null}
              {" "}
            </div>
            {" "}
          </header>
          {" "}
          {v.showMenu ? (
            <>
              {" "}
              <nav id="mobile-menu" aria-label="Primary" style={{ position: "absolute", zIndex: "6", top: "84px", left: "14px", right: "14px", maxWidth: "380px", marginLeft: "auto", display: "flex", flexDirection: "column", gap: "2px", padding: "10px", borderRadius: "24px", background: "linear-gradient(180deg, rgba(255,255,255,0.10), rgba(255,255,255,0.04))", backdropFilter: "blur(22px) saturate(170%)", WebkitBackdropFilter: "blur(22px) saturate(170%)", border: "1px solid rgba(255,255,255,0.18)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.3), 0 16px 44px rgba(0,0,0,0.5)" }}>
                {" "}
                <a className="adp4" href="#" onClick={v.mk0} style={{ display: "flex", alignItems: "center", minHeight: "44px", padding: "0 12px", borderRadius: "10px", fontSize: "16px" }}>
                  {"Home"}
                </a>
                {" "}
                <a className="adp4" href="#features" onClick={v.mk1} style={{ display: "flex", alignItems: "center", minHeight: "44px", padding: "0 12px", borderRadius: "10px", fontSize: "16px" }}>
                  {"Features"}
                </a>
                {" "}
                <a className="adp4" href="#how-it-works" onClick={v.mk2} style={{ display: "flex", alignItems: "center", minHeight: "44px", padding: "0 12px", borderRadius: "10px", fontSize: "16px" }}>
                  {"How it works"}
                </a>
                {" "}
                <a className="adp4" href="#use-cases" onClick={v.mk3} style={{ display: "flex", alignItems: "center", minHeight: "44px", padding: "0 12px", borderRadius: "10px", fontSize: "16px" }}>
                  {"Use Cases"}
                </a>
                {" "}
                <a className="adp4" href="#pricing" onClick={v.mk4} style={{ display: "flex", alignItems: "center", minHeight: "44px", padding: "0 12px", borderRadius: "10px", fontSize: "16px" }}>
                  {"Pricing"}
                </a>
                {" "}
                <a href="#" data-soon="signup" style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "46px", marginTop: "8px", borderRadius: "999px", border: "1px solid rgba(214,222,240,0.38)", fontSize: "15px" }}>
                  {"Try AutoDub"}
                </a>
                {" "}
              </nav>
              {" "}
            </>
          ) : null}
          {" "}
          <div style={{ position: "relative", width: "100%", minHeight: v.heroMinH, display: "flex", flexDirection: "column", justifyContent: "center" }}>
            {" "}
            <svg ref={v.svgRef} aria-hidden="true" focusable="false" viewBox="-952 0 2856 687" preserveAspectRatio="xMidYMin meet" style={{ willChange: "transform", position: "absolute", top: "0", left: "calc(50% - clamp(560px, min(100cqw, 130svh), 1800px) * 1.5)", width: "calc(clamp(560px, min(100cqw, 130svh), 1800px) * 3)", height: "calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.7216)", pointerEvents: "none", overflow: "visible" }}>
              <defs>
                <linearGradient id="gridFade" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="687">
                  <stop offset="0" stopColor="#fff" stopOpacity="1" />
                  <stop offset="0.55" stopColor="#fff" stopOpacity="0.7" />
                  <stop offset="1" stopColor="#fff" stopOpacity="0" />
                </linearGradient>
                <mask id="gridMask" maskUnits="userSpaceOnUse" x="-952" y="0" width="2856" height="687">
                  <rect x="-952" y="0" width="2856" height="687" fill="url(#gridFade)" />
                </mask>
                <radialGradient id="illum" gradientUnits="userSpaceOnUse" cx="476" cy="190" r="360" gradientTransform="translate(476 190) scale(1 0.8) translate(-476 -190)">
                  <stop offset="0" stopColor="#4860ff" stopOpacity="0.34" />
                  <stop offset="0.45" stopColor="#3a2fa8" stopOpacity="0.16" />
                  <stop offset="1" stopColor="#0b1440" stopOpacity="0" />
                </radialGradient>
                <linearGradient id="beam" gradientUnits="userSpaceOnUse" x1="0" y1="60" x2="0" y2="330">
                  <stop offset="0" stopColor="#4860ff" stopOpacity="0.10" />
                  <stop offset="1" stopColor="#4860ff" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="lowerFade" gradientUnits="userSpaceOnUse" x1="0" y1="385" x2="0" y2="505">
                  <stop offset="0" stopColor="#fff" stopOpacity="1" />
                  <stop offset="0.55" stopColor="#fff" stopOpacity="0.55" />
                  <stop offset="1" stopColor="#fff" stopOpacity="0" />
                </linearGradient>
                <mask id="arcMask" maskUnits="userSpaceOnUse" x="-952" y="0" width="2856" height="687">
                  <rect x="-952" y="0" width="2856" height="687" fill="url(#lowerFade)" />
                </mask>
                <radialGradient id="outerBase" gradientUnits="userSpaceOnUse" cx="476" cy="633" r="400">
                  <stop offset="0.815" stopColor="#4048d8" />
                  <stop offset="0.9" stopColor="#4860ff" />
                  <stop offset="1" stopColor="#4860ff" />
                </radialGradient>
                <radialGradient id="outerTop" gradientUnits="userSpaceOnUse" cx="476" cy="236" r="330" gradientTransform="translate(476 236) scale(1 0.7) translate(-476 -236)">
                  <stop offset="0" stopColor="#8ce6ff" stopOpacity="0.9" />
                  <stop offset="0.3" stopColor="#4860ff" stopOpacity="0.5" />
                  <stop offset="1" stopColor="#4860ff" stopOpacity="0" />
                </radialGradient>
                <linearGradient id="outerShade" gradientUnits="userSpaceOnUse" x1="0" y1="250" x2="0" y2="500">
                  <stop offset="0" stopColor="#040a33" stopOpacity="0" />
                  <stop offset="1" stopColor="#040a33" stopOpacity="0.6" />
                </linearGradient>
                <linearGradient id="outerRim" gradientUnits="userSpaceOnUse" x1="0" y1="233" x2="0" y2="440">
                  <stop offset="0" stopColor="#dcefff" stopOpacity="0.95" />
                  <stop offset="0.35" stopColor="#b9dcff" stopOpacity="0.55" />
                  <stop offset="1" stopColor="#9cc8ff" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="outerGlowGrad" gradientUnits="userSpaceOnUse" x1="0" y1="225" x2="0" y2="400">
                  <stop offset="0" stopColor="#8ce6ff" stopOpacity="0.75" />
                  <stop offset="1" stopColor="#8ce6ff" stopOpacity="0" />
                </linearGradient>
                <radialGradient id="innerFill" gradientUnits="userSpaceOnUse" cx="476" cy="633" r="259">
                  <stop offset="0.74" stopColor="#0a0c1a" stopOpacity="0" />
                  <stop offset="0.9" stopColor="#10152b" stopOpacity="0.85" />
                  <stop offset="1" stopColor="#161c37" stopOpacity="1" />
                </radialGradient>
                <linearGradient id="innerRim" gradientUnits="userSpaceOnUse" x1="0" y1="374" x2="0" y2="470">
                  <stop offset="0" stopColor="#a9b8dc" stopOpacity="0.6" />
                  <stop offset="0.5" stopColor="#7f8fb8" stopOpacity="0.25" />
                  <stop offset="1" stopColor="#7f8fb8" stopOpacity="0" />
                </linearGradient>
                <filter id="blur10" filterUnits="userSpaceOnUse" x="-952" y="-200" width="2856" height="1087">
                  <feGaussianBlur stdDeviation="10" />
                </filter>
                <filter id="blur4" filterUnits="userSpaceOnUse" x="-952" y="-200" width="2856" height="1087">
                  <feGaussianBlur stdDeviation="4" />
                </filter>
                <radialGradient id="spotGrad">
                  <stop offset="0" stopColor="#fff" stopOpacity="1" />
                  <stop offset="0.35" stopColor="#fff" stopOpacity="0.55" />
                  <stop offset="0.7" stopColor="#fff" stopOpacity="0.15" />
                  <stop offset="1" stopColor="#fff" stopOpacity="0" />
                </radialGradient>
                <radialGradient id="spotGlow">
                  <stop offset="0" stopColor="#8ce6ff" stopOpacity="0.11" />
                  <stop offset="0.5" stopColor="#4860ff" stopOpacity="0.04" />
                  <stop offset="1" stopColor="#4a50d0" stopOpacity="0" />
                </radialGradient>
                <mask id="spotMask" maskUnits="userSpaceOnUse" x="-952" y="-400" width="2856" height="1487">
                  <circle ref={v.spotMaskRef} cx="476" cy="300" r="290" fill="url(#spotGrad)" />
                </mask>
              </defs>
              <g id="layer-grid" mask="url(#gridMask)" style={{ display: v.gridDisplay }}>
                {(v.gridVB || []).map((x, $index) => (
                  <React.Fragment key={$index}>
                    <path data-w="v" data-x={x.x} data-a="0" data-b="687" d={x.d} fill="none" stroke="#ffffff" strokeOpacity="0.055" strokeWidth="1" />
                  </React.Fragment>
                ))}
                <path data-w="h" data-y="148" data-a="-952" data-b="1904" d="M-952 148H1904" fill="none" stroke="#ffffff" strokeOpacity="0.055" strokeWidth="1" />
                <path data-w="h" data-y="345" data-a="-952" data-b="1904" d="M-952 345H1904" fill="none" stroke="#ffffff" strokeOpacity="0.05" strokeWidth="1" />
                <path data-w="h" data-y="541" data-a="-952" data-b="1904" d="M-952 541H1904" fill="none" stroke="#ffffff" strokeOpacity="0.045" strokeWidth="1" />
                <circle data-w="d" data-x="181" data-y="148" cx="181" cy="148" r="2" fill="#ffffff" fillOpacity="0.16" />
                <circle data-w="d" data-x="772" data-y="148" cx="772" cy="148" r="2" fill="#ffffff" fillOpacity="0.16" />
                <circle data-w="d" data-x="-16" data-y="345" cx="-16" cy="345" r="1.6" fill="#ffffff" fillOpacity="0.1" />
                <circle data-w="d" data-x="968" data-y="345" cx="968" cy="345" r="1.6" fill="#ffffff" fillOpacity="0.1" />
              </g>
              <g id="layer-cursor-light" ref={v.spotRef} style={{ opacity: "0", transition: "opacity 500ms ease" }}>
                <circle ref={v.spotGlowRef} cx="476" cy="300" r="380" fill="url(#spotGlow)" />
                <g mask="url(#spotMask)" stroke="#d4defa" strokeWidth="1">
                  {(v.gridVL || []).map((x, $index) => (
                    <React.Fragment key={$index}>
                      <path data-w="v" data-x={x.x} data-a="-200" data-b="1087" d={x.d} fill="none" strokeOpacity="0.28" />
                    </React.Fragment>
                  ))}
                  {(v.gridHL || []).map((y, $index) => (
                    <React.Fragment key={$index}>
                      <path data-w="h" data-y={y.y} data-a="-952" data-b="1904" d={y.d} fill="none" strokeOpacity="0.28" />
                    </React.Fragment>
                  ))}
                  {(v.gridDots || []).map((d, $index) => (
                    <React.Fragment key={$index}>
                      <circle data-w="d" data-x={d.x} data-y={d.y} cx={d.x} cy={d.y} r="2" fill="#e4ebff" fillOpacity="0.7" stroke="none" />
                    </React.Fragment>
                  ))}
                </g>
              </g>
            </svg>
            {" "}
            <div ref={v.heroInRef} style={{ position: "relative", zIndex: "2", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: `${v.heroPadT} 20px ${v.heroPadB}` }}>
              {" "}
              <div style={{ display: "inline-flex", alignItems: "center", gap: "10px", marginBottom: "calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.022)" }}>
                {" "}
                <div style={{ display: "flex", alignItems: "center" }}>
                  {" "}
                  <img src={"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=128&h=128&fit=crop&crop=faces&auto=format&q=70"} alt="" style={{ width: "24px", height: "24px", borderRadius: "50%", objectFit: "cover", boxShadow: "0 0 0 2px #b36bff", position: "relative", zIndex: "4" }} />
                  {" "}
                  <img src={"https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=128&h=128&fit=crop&crop=faces&auto=format&q=70"} alt="" style={{ width: "24px", height: "24px", borderRadius: "50%", objectFit: "cover", boxShadow: "0 0 0 2px #3ad6c4", marginLeft: "-6px", position: "relative", zIndex: "3" }} />
                  {" "}
                  <img src={"https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=128&h=128&fit=crop&crop=faces&auto=format&q=70"} alt="" style={{ width: "24px", height: "24px", borderRadius: "50%", objectFit: "cover", boxShadow: "0 0 0 2px #5b8cff", marginLeft: "-6px", position: "relative", zIndex: "2" }} />
                  {" "}
                  <img src={"https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=128&h=128&fit=crop&crop=faces&auto=format&q=70"} alt="" style={{ width: "24px", height: "24px", borderRadius: "50%", objectFit: "cover", boxShadow: "0 0 0 2px #ff7ab8", marginLeft: "-6px", position: "relative", zIndex: "1" }} />
                  {" "}
                </div>
                {" "}
                <span ref={v.trustRef} aria-label="1420+ monthly users" style={{ display: "inline-block", textAlign: "left", fontSize: "13px", lineHeight: "1", color: "rgba(220,228,255,0.82)", letterSpacing: "0.005em", whiteSpace: "nowrap", fontVariantNumeric: "tabular-nums" }}>
                  {"1420+ monthly users"}
                </span>
                {" "}
              </div>
              {" "}
              <h1 style={{ margin: "0", maxWidth: "100%", fontSize: "min(calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.07), 7.9cqw)", whiteSpace: "nowrap", fontWeight: "500", lineHeight: "1.02", letterSpacing: "-0.048em", color: "#e9eef8", padding: "0 0.04em 0.06em" }}>
                <span style={{ display: "block", width: "fit-content", whiteSpace: "nowrap", margin: "0 auto", padding: "0 0.04em 0.06em", background: "linear-gradient(180deg, #f1f6ff 0%, #cfdcf3 42%, #9aaccc 78%, #8496bb 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent" }}>
                  {"Automated Video Dubbing"}
                </span>
                <span style={{ display: "block", width: "fit-content", whiteSpace: "nowrap", margin: "0 auto", padding: "0 0.04em 0.06em" }}>
                  <span style={{ background: "linear-gradient(180deg, #f1f6ff 0%, #cfdcf3 42%, #9aaccc 78%, #8496bb 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent", padding: "0 0.04em 0.06em" }}>
                    {"in"}
                  </span>
                  {" "}
                  <span style={{ display: "inline-block", whiteSpace: "nowrap", fontFamily: "'Pinyon Script', 'Snell Roundhand', cursive", fontWeight: "400", fontSize: "1.22em", lineHeight: "1.15", letterSpacing: "0", padding: "0.1em 0.16em 0.28em 0.08em", margin: "-0.18em -0.08em -0.36em -0.04em", verticalAlign: "-0.06em", background: "linear-gradient(180deg, #f1f6ff 0%, #cfdcf3 42%, #9aaccc 78%, #8496bb 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent" }}>
                    {"Every Language"}
                  </span>
                </span>
              </h1>
              {" "}
              <p style={{ margin: "calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.025) 0 0", maxWidth: "min(max(calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.45), 420px), 100%)", fontSize: "clamp(15px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.0158), 18px)", lineHeight: "1.45", color: "#9a9fb1", letterSpacing: "-0.005em", textWrap: "balance" }}>
                {"Translate your videos into other languages with AI dubbing designed to preserve the original voices and meaning."}
              </p>
              {" "}
              <div style={{ marginTop: "calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.042)", display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "center", gap: "12px" }}>
                {" "}
                <a className="adp5 adp6 adp7" href="#" data-soon="signup" ref={v.sbRef} onMouseMove={v.sbMove} onMouseEnter={v.sbMove} onMouseLeave={v.sbLeave} style={{ position: "relative", isolation: "isolate", display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "0.5em", height: "clamp(44px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.046), 54px)", padding: "0 clamp(22px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.024), 30px)", borderRadius: "999px", fontWeight: "500", lineHeight: "1", letterSpacing: "0.01em", fontSize: "clamp(14px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.0145), 17px)", color: "#ffffff", whiteSpace: "nowrap", border: "1.2px solid transparent", boxSizing: "border-box", background: "radial-gradient(36% 46% at 50% 112%, rgba(140,235,255,0.75) 0%, rgba(140,235,255,0) 100%) padding-box, radial-gradient(75% 105% at 50% 125%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.50) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%) padding-box, linear-gradient(165deg, #1b1f38 0%, #12152a 55%, #0d1022 100%) padding-box, linear-gradient(180deg, rgba(255,255,255,0.32) 0%, rgba(255,255,255,0.06) 38%, rgba(130,110,255,0.6) 78%, rgba(150,235,255,0.95) 100%) border-box", boxShadow: "0 10px 28px -12px rgba(72,96,255,0.6), 0 6px 20px -10px rgba(140,235,255,0.35)", WebkitTapHighlightColor: "transparent", outline: "none", transition: "transform 0.25s cubic-bezier(0.2, 0.8, 0.2, 1), background 160ms ease, box-shadow 160ms ease" }}>
                  <svg ref={v.sbSvgRef} aria-hidden="true" focusable="false" style={{ willChange: "transform", position: "absolute", inset: "-24px", zIndex: "1", display: "block", width: "calc(100% + 48px)", height: "calc(100% + 48px)", pointerEvents: "none", overflow: "visible" }}>
                    <defs>
                      <filter id="sbBlur" x="-50%" y="-50%" width="200%" height="200%">
                        <feGaussianBlur stdDeviation="3" />
                      </filter>
                      <radialGradient id="sbEdge" gradientUnits="userSpaceOnUse" cx="40" cy="24" r="90">
                        <stop offset="0" stopColor="#ffffff" stopOpacity="1" />
                        <stop offset="0.4" stopColor="#cfe6ff" stopOpacity="0.85" />
                        <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
                      </radialGradient>
                      <radialGradient id="sbGlow" gradientUnits="userSpaceOnUse" cx="40" cy="24" r="90">
                        <stop offset="0" stopColor="#e8f3ff" stopOpacity="0.32" />
                        <stop offset="0.5" stopColor="#bcdcff" stopOpacity="0.1" />
                        <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
                      </radialGradient>
                    </defs>
                    <rect data-sb="glow" x="24" y="24" width="0" height="0" rx="0" fill="url(#sbGlow)" />
                    <rect data-sb="base" x="24.5" y="24.5" width="0" height="0" rx="0" fill="none" stroke="#8ce6ff" strokeOpacity="0" strokeWidth="1" />
                    <rect data-sb="edgeglow" x="24.5" y="24.5" width="0" height="0" rx="0" fill="none" stroke="url(#sbEdge)" strokeWidth="4.5" filter="url(#sbBlur)" opacity="0.95" />
                    <rect data-sb="edge" x="24.5" y="24.5" width="0" height="0" rx="0" fill="none" stroke="url(#sbEdge)" strokeWidth="2" />
                  </svg>
                  <span style={{ position: "relative", zIndex: "2", display: "inline-flex", alignItems: "center", gap: "inherit" }}>
                    <span>
                      {"Get Started"}
                    </span>
                    <svg aria-hidden="true" width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" style={{ display: "block" }}>
                      <line x1="2.5" y1="7" x2="11" y2="7" />
                      <polyline points="7.5 3.5 11 7 7.5 10.5" />
                    </svg>
                  </span>
                </a>
                {" "}
                <a className="adp8 adp9" href="#" data-soon="sample" style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "10px", height: "clamp(44px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.046), 54px)", padding: "0 clamp(18px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.02), 26px) 0 clamp(8px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.008), 10px)", borderRadius: "999px", background: "rgba(255,255,255,0.045)", backdropFilter: "blur(12px) saturate(1.4)", WebkitBackdropFilter: "blur(12px) saturate(1.4)", boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.12), inset 1.5px 1.5px 1px -0.5px rgba(255,255,255,0.4), inset -1.5px -1.5px 1px -0.5px rgba(255,255,255,0.14), 0 8px 24px rgba(0,0,0,0.35)", color: "#eef1f8", fontSize: "clamp(14px, calc(clamp(560px, min(100cqw, 130svh), 1800px) * 0.0145), 17px)", letterSpacing: "-0.015em", whiteSpace: "nowrap", transition: "background 180ms ease" }}>
                  <span aria-hidden="true" style={{ width: "28px", height: "28px", borderRadius: "999px", background: "rgba(255,255,255,0.12)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.3)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <svg width="10" height="11" viewBox="0 0 10 11" style={{ display: "block", marginLeft: "2px" }}>
                      <polygon points="1,1 9,5.5 1,10" fill="#ffffff" />
                    </svg>
                  </span>
                  <span>
                    {"Hear a sample"}
                  </span>
                </a>
                {" "}
              </div>
              {" "}
            </div>
            {" "}
          </div>
          {" "}
          <div data-screen-label="Hero image" style={{ position: "relative", zIndex: "2", width: "100%", display: "flex", justifyContent: "center", padding: "0 clamp(20px, 4cqw, 72px) 0", marginTop: "-14svh" }}>
            {" "}
            <div ref={v.videoInRef} style={{ position: "relative", width: "min(1640px, 100%)", aspectRatio: v.cardAR, borderRadius: "clamp(16px, 2cqw, 26px)" }}>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "-18px", borderRadius: "calc(clamp(16px, 2cqw, 26px) + 18px)", background: "radial-gradient(closest-side, rgba(72,96,255,0) 0%, rgba(72,96,255,0) 82%, rgba(72,96,255,0.28) 100%)", filter: "blur(24px)", pointerEvents: "none", transform: "translateZ(0)" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", left: "4%", right: "4%", top: "-90px", height: "220px", pointerEvents: "none", background: "radial-gradient(50% 50% at 50% 50%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%)", filter: "blur(34px)", opacity: "0.8", transform: "translateZ(0)" }} />
              <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", top: "-14px", height: "28px", borderRadius: "50%", pointerEvents: "none", background: "rgba(140,235,255,0.75)", filter: "blur(18px)", transform: "translateZ(0)" }} />
              {" "}
              <div style={{ position: "relative", width: "100%", height: "100%", borderRadius: "clamp(16px, 2cqw, 26px)", overflow: "hidden", background: "#0d1020" }}>
                {" "}
                <img src={"https://images.unsplash.com/photo-1581368135153-a506cf13b1e1?fm=jpg&q=70&w=2000&auto=format&fit=crop"} alt="Podcaster with headphones speaking into a mic in a dark wood-and-brick studio" style={{ position: "absolute", inset: "0", width: "100%", height: "100%", objectFit: "cover", objectPosition: "50% 35%", display: "block", filter: "saturate(0.85) brightness(0.9)" }} />
                {" "}
                <div aria-hidden="true" style={{ position: "absolute", inset: "0", background: "linear-gradient(180deg, rgba(8,9,19,0.05) 0%, rgba(8,9,19,0.3) 55%, rgba(8,9,19,0.86) 100%), radial-gradient(120% 90% at 50% 45%, rgba(8,9,19,0) 55%, rgba(8,9,19,0.55) 100%), linear-gradient(180deg, rgba(72,96,255,0.08), rgba(72,96,255,0.03))" }} />
                {" "}
                {v.isMobile ? (
                  <>
                    <div aria-hidden="true" style={{ position: "absolute", inset: "0", background: "linear-gradient(180deg, rgba(8,9,19,0) 0%, rgba(8,9,19,0) 40%, rgba(8,9,19,0.45) 78%, rgba(8,9,19,0.9) 100%)" }} />
                  </>
                ) : null}
                {" "}
              </div>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "clamp(16px, 2cqw, 26px)", pointerEvents: "none", padding: "6px", background: "linear-gradient(90deg, rgba(80,115,255,0.7) 0%, rgba(100,150,255,0.78) 25%, rgba(150,235,255,0.92) 50%, rgba(100,150,255,0.78) 75%, rgba(80,115,255,0.7) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)", filter: "blur(10px)", opacity: "0.6", transform: "translateZ(0)" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "clamp(16px, 2cqw, 26px)", pointerEvents: "none", padding: "3px", background: "linear-gradient(90deg, rgba(80,115,255,0.7) 0%, rgba(100,150,255,0.78) 25%, rgba(150,235,255,0.92) 50%, rgba(100,150,255,0.78) 75%, rgba(80,115,255,0.7) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)", filter: "blur(3px)", opacity: "0.75" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "clamp(16px, 2cqw, 26px)", pointerEvents: "none", padding: "1.5px", background: "linear-gradient(90deg, rgba(150,175,255,0.7) 0%, rgba(165,200,255,0.8) 25%, rgba(205,245,255,0.95) 50%, rgba(165,200,255,0.8) 75%, rgba(150,175,255,0.7) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
              {" "}
              <svg ref={v.cbSvgRef} aria-hidden="true" focusable="false" style={{ willChange: "transform", position: "absolute", inset: "-24px", width: "calc(100% + 48px)", height: "calc(100% + 48px)", pointerEvents: "none", overflow: "visible", zIndex: "3" }}>
                <defs>
                  <filter id="cbBlur" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="9" />
                  </filter>
                  <radialGradient id="cbEdge" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="260">
                    <stop offset="0" stopColor="#ffffff" stopOpacity="1" />
                    <stop offset="0.25" stopColor="#8ce6ff" stopOpacity="0.9" />
                    <stop offset="0.58" stopColor="#4860ff" stopOpacity="0.55" />
                    <stop offset="1" stopColor="#4860ff" stopOpacity="0" />
                  </radialGradient>
                  <radialGradient id="cbEdge2" gradientUnits="userSpaceOnUse" cx="0" cy="0" r="260">
                    <stop offset="0" stopColor="#ffffff" stopOpacity="1" />
                    <stop offset="0.25" stopColor="#8ce6ff" stopOpacity="0.9" />
                    <stop offset="0.58" stopColor="#4860ff" stopOpacity="0.55" />
                    <stop offset="1" stopColor="#4860ff" stopOpacity="0" />
                  </radialGradient>
                </defs>
                <rect data-cb="glow" x="24" y="24" width="0" height="0" rx="0" fill="none" stroke="url(#cbEdge)" strokeWidth="12" filter="url(#cbBlur)" opacity="0.95" />
                <rect data-cb="edge" x="24" y="24" width="0" height="0" rx="0" fill="none" stroke="url(#cbEdge)" strokeWidth="3.5" />
                <rect data-cb="glow" x="24" y="24" width="0" height="0" rx="0" fill="none" stroke="url(#cbEdge2)" strokeWidth="12" filter="url(#cbBlur)" opacity="0.95" />
                <rect data-cb="edge" x="24" y="24" width="0" height="0" rx="0" fill="none" stroke="url(#cbEdge2)" strokeWidth="3.5" />
              </svg>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "clamp(16px, 2cqw, 26px)", pointerEvents: "none", boxShadow: "inset 0 0 24px rgba(90,140,255,0.28), inset 0 0 80px rgba(60,100,230,0.15)" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", zIndex: "4", left: "-90px", right: "-90px", top: "38%", bottom: "-70px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(8,9,19,0) 0%, rgba(8,9,19,0.55) 28%, rgba(8,9,19,0.9) 55%, #080913 78%)" }} />
              {" "}
            </div>
            {" "}
          </div>
          {" "}
          <div data-screen-label="Logo ticker" style={{ position: "relative", zIndex: "5", display: "flex", flexDirection: "column", alignItems: "center", gap: "clamp(16px, 1.9cqw, 24px)", padding: "0 0 clamp(40px, 6svh, 72px)", marginTop: "calc(-1 * clamp(0px, 3.5cqw, 60px))" }}>
            {" "}
            <p style={{ margin: "0", fontSize: "clamp(13px, 1.1cqw, 15px)", letterSpacing: "0.01em", color: "#b4b9cb", textAlign: "center" }}>
              {"Trusted by 10,000+ creators worldwide"}
            </p>
            {" "}
            <div style={{ position: "relative", width: "min(1100px, 100%)", overflow: "hidden", WebkitMaskImage: "linear-gradient(90deg, transparent 0%, #000 16%, #000 84%, transparent 100%)", maskImage: "linear-gradient(90deg, transparent 0%, #000 16%, #000 84%, transparent 100%)" }}>
              {" "}
              <div ref={v.tkTrackRef} style={{ display: "flex", width: "max-content", willChange: "transform" }}>
                {" "}
                <div ref={v.tkGroupRef} style={{ display: "flex", alignItems: "center", gap: "clamp(30px, 5cqw, 72px)", paddingRight: "clamp(30px, 5cqw, 72px)", color: "#c9cedc", opacity: "0.78" }}>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.43em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "600", letterSpacing: "-0.03em", whiteSpace: "nowrap" }}>
                    <span style={{ width: "0.95em", height: "0.95em", borderRadius: "50%", border: "0.19em solid currentColor" }} />
                    {"Northwave"}
                  </span>
                  {" "}
                  <span style={{ fontSize: "clamp(16px, 4.5cqw, 22px)", fontWeight: "600", letterSpacing: "0.08em", whiteSpace: "nowrap" }}>
                    {"LOOPCAST"}
                  </span>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.43em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "500", letterSpacing: "-0.02em", whiteSpace: "nowrap" }}>
                    <span style={{ width: "0.86em", height: "0.86em", borderRadius: "4px", background: "currentColor", transform: "rotate(45deg)" }} />
                    {"Kinetic"}
                  </span>
                  {" "}
                  <span style={{ fontSize: "clamp(16px, 4.5cqw, 22px)", fontWeight: "400", letterSpacing: "-0.02em", whiteSpace: "nowrap" }}>
                    {"studio"}
                    <span style={{ fontWeight: "600" }}>
                      {"/nine"}
                    </span>
                  </span>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.38em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "600", letterSpacing: "-0.03em", whiteSpace: "nowrap" }}>
                    <span style={{ display: "flex", gap: "3px" }}>
                      <span style={{ width: "0.38em", height: "0.95em", borderRadius: "0.19em", background: "currentColor" }} />
                      <span style={{ width: "0.38em", height: "0.95em", borderRadius: "0.19em", background: "currentColor", opacity: "0.55" }} />
                    </span>
                    {"Parallel"}
                  </span>
                  {" "}
                  <span style={{ fontSize: "clamp(17px, 4.7cqw, 23px)", fontWeight: "500", fontStyle: "italic", letterSpacing: "-0.04em", whiteSpace: "nowrap" }}>
                    {"echo.fm"}
                  </span>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.43em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "600", letterSpacing: "-0.02em", whiteSpace: "nowrap" }}>
                    <span style={{ width: "1.05em", height: "1.05em", borderRadius: "50%", background: "radial-gradient(circle, currentColor 0 30%, transparent 32%), conic-gradient(currentColor 0 25%, transparent 0 50%, currentColor 0 75%, transparent 0)" }} />
                    {"Orbitly"}
                  </span>
                  {" "}
                </div>
                {" "}
                <div aria-hidden="true" style={{ display: "flex", alignItems: "center", gap: "clamp(30px, 5cqw, 72px)", paddingRight: "clamp(30px, 5cqw, 72px)", color: "#c9cedc", opacity: "0.78" }}>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.43em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "600", letterSpacing: "-0.03em", whiteSpace: "nowrap" }}>
                    <span style={{ width: "0.95em", height: "0.95em", borderRadius: "50%", border: "0.19em solid currentColor" }} />
                    {"Northwave"}
                  </span>
                  {" "}
                  <span style={{ fontSize: "clamp(16px, 4.5cqw, 22px)", fontWeight: "600", letterSpacing: "0.08em", whiteSpace: "nowrap" }}>
                    {"LOOPCAST"}
                  </span>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.43em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "500", letterSpacing: "-0.02em", whiteSpace: "nowrap" }}>
                    <span style={{ width: "0.86em", height: "0.86em", borderRadius: "4px", background: "currentColor", transform: "rotate(45deg)" }} />
                    {"Kinetic"}
                  </span>
                  {" "}
                  <span style={{ fontSize: "clamp(16px, 4.5cqw, 22px)", fontWeight: "400", letterSpacing: "-0.02em", whiteSpace: "nowrap" }}>
                    {"studio"}
                    <span style={{ fontWeight: "600" }}>
                      {"/nine"}
                    </span>
                  </span>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.38em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "600", letterSpacing: "-0.03em", whiteSpace: "nowrap" }}>
                    <span style={{ display: "flex", gap: "3px" }}>
                      <span style={{ width: "0.38em", height: "0.95em", borderRadius: "0.19em", background: "currentColor" }} />
                      <span style={{ width: "0.38em", height: "0.95em", borderRadius: "0.19em", background: "currentColor", opacity: "0.55" }} />
                    </span>
                    {"Parallel"}
                  </span>
                  {" "}
                  <span style={{ fontSize: "clamp(17px, 4.7cqw, 23px)", fontWeight: "500", fontStyle: "italic", letterSpacing: "-0.04em", whiteSpace: "nowrap" }}>
                    {"echo.fm"}
                  </span>
                  {" "}
                  <span style={{ display: "inline-flex", alignItems: "center", gap: "0.43em", fontSize: "clamp(16px, 4.3cqw, 21px)", fontWeight: "600", letterSpacing: "-0.02em", whiteSpace: "nowrap" }}>
                    <span style={{ width: "1.05em", height: "1.05em", borderRadius: "50%", background: "radial-gradient(circle, currentColor 0 30%, transparent 32%), conic-gradient(currentColor 0 25%, transparent 0 50%, currentColor 0 75%, transparent 0)" }} />
                    {"Orbitly"}
                  </span>
                  {" "}
                </div>
                {" "}
              </div>
              {" "}
            </div>
            {" "}
          </div>
          {" "}
        </section>
        {" "}
        <section ref={v.probRef} id="features" data-screen-label="Features" aria-label="Features" style={{ position: "relative", overflow: "hidden", padding: "clamp(60px, 6.2cqw, 100px) clamp(20px, 4cqw, 72px) clamp(32px, 3.2cqw, 52px)", background: "#080913" }}>
          {" "}
          <div data-rv="0" aria-hidden="true" style={{ position: "absolute", inset: "0", pointerEvents: "none", opacity: "0", transition: "opacity 1.8s ease" }} />
          {" "}
          <div style={{ position: "relative", zIndex: "2", maxWidth: "1320px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "clamp(14px, 1.4cqw, 20px)" }}>
            {" "}
            <div style={{ display: "flex", flexWrap: "wrap", gap: "clamp(14px, 1.4cqw, 20px)" }}>
              {" "}
              <div data-rv="0" style={{ flex: "1 1 250px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,60px,0)", filter: "blur(6px)", transition: "opacity 0.9s cubic-bezier(0.2,0.7,0.2,1), transform 1.1s cubic-bezier(0.2,0.7,0.2,1), filter 0.9s cubic-bezier(0.2,0.7,0.2,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", overflow: "hidden", boxSizing: "border-box", minHeight: "clamp(380px, 31cqw, 420px)", display: "flex", flexDirection: "column", isolation: "isolate", borderRadius: "22px", background: "radial-gradient(75% 38% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.5s cubic-bezier(0.2,0.7,0.2,1), border-color 0.4s ease" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "relative", flex: "1", minHeight: "210px", display: "flex", alignItems: "center", justifyContent: "center", padding: "30px clamp(20px, 2cqw, 28px) 10px" }}>
                    {" "}
                    <div style={{ width: "100%", maxWidth: "300px", display: "flex", flexDirection: "column", gap: "20px" }}>
                      {" "}
                      <div style={{ display: "flex" }}>
                        <div style={{ flex: "1", display: "flex", flexDirection: "column", alignItems: "center", gap: "7px" }}>
                          <img data-spk-av="1" src={"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&h=160&fit=crop&crop=faces&auto=format&q=70"} alt="" style={{ width: "36px", height: "36px", borderRadius: "50%", objectFit: "cover", boxShadow: "0 0 0 2px #4860ff, 0 0 20px #4860ff66", opacity: "0.45", transition: "opacity 0.4s ease, transform 0.4s cubic-bezier(0.2,0.7,0.2,1)" }} />
                          <span style={{ fontSize: "11px", letterSpacing: "0.02em", color: "#9a9fb1" }}>
                            {"Speaker 1"}
                          </span>
                        </div>
                        <div style={{ flex: "1", display: "flex", flexDirection: "column", alignItems: "center", gap: "7px" }}>
                          <img data-spk-av="1" src={"https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=160&h=160&fit=crop&crop=faces&auto=format&q=70"} alt="" style={{ width: "36px", height: "36px", borderRadius: "50%", objectFit: "cover", boxShadow: "0 0 0 2px #8ce6ff, 0 0 20px #8ce6ff66", opacity: "0.45", transition: "opacity 0.4s ease, transform 0.4s cubic-bezier(0.2,0.7,0.2,1)" }} />
                          <span style={{ fontSize: "11px", letterSpacing: "0.02em", color: "#9a9fb1" }}>
                            {"Speaker 2"}
                          </span>
                        </div>
                        <div style={{ flex: "1", display: "flex", flexDirection: "column", alignItems: "center", gap: "7px" }}>
                          <img data-spk-av="1" src={"https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=160&h=160&fit=crop&crop=faces&auto=format&q=70"} alt="" style={{ width: "36px", height: "36px", borderRadius: "50%", objectFit: "cover", boxShadow: "0 0 0 2px #826eff, 0 0 20px #826eff66", opacity: "0.45", transition: "opacity 0.4s ease, transform 0.4s cubic-bezier(0.2,0.7,0.2,1)" }} />
                          <span style={{ fontSize: "11px", letterSpacing: "0.02em", color: "#9a9fb1" }}>
                            {"Speaker 3"}
                          </span>
                        </div>
                      </div>
                      {" "}
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: "64px" }}>
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#4860ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#8ce6ff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                        <span data-spk-bar="1" data-g="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "#826eff", transform: "scaleY(0.2)" }} />
                      </div>
                      {" "}
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ position: "relative", padding: "0 clamp(20px, 2cqw, 28px) clamp(22px, 2cqw, 28px)", display: "flex", flexDirection: "column", gap: "8px" }}>
                    {" "}
                    <h3 style={{ margin: "0", fontSize: "clamp(18px, 1.45cqw, 21px)", fontWeight: "500", lineHeight: "1.2", letterSpacing: "-0.03em", color: "#e9eef8" }}>
                      {"Multi-Speaker Recognition"}
                    </h3>
                    {" "}
                    <p style={{ margin: "0", maxWidth: "30em", fontSize: "14px", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                      {"Detects every voice in interviews, panels and podcasts, and gives each speaker their own dubbed voice."}
                    </p>
                    {" "}
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
              <div data-rv="1" style={{ flex: "1 1 250px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,60px,0)", filter: "blur(6px)", transition: "opacity 0.9s cubic-bezier(0.2,0.7,0.2,1), transform 1.1s cubic-bezier(0.2,0.7,0.2,1), filter 0.9s cubic-bezier(0.2,0.7,0.2,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", overflow: "hidden", boxSizing: "border-box", minHeight: "clamp(380px, 31cqw, 420px)", display: "flex", flexDirection: "column", isolation: "isolate", borderRadius: "22px", background: "radial-gradient(75% 38% at 62% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.5s cubic-bezier(0.2,0.7,0.2,1), border-color 0.4s ease" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "relative", flex: "1", minHeight: "210px", display: "flex", alignItems: "center", justifyContent: "center", padding: "30px clamp(20px, 2cqw, 28px) 10px" }}>
                    {" "}
                    <div style={{ width: "100%", maxWidth: "320px", display: "flex", flexDirection: "column", alignItems: "center", gap: "12px" }}>
                      {" "}
                      <div style={{ display: "inline-flex", alignItems: "center", gap: "8px", height: "30px", padding: "0 14px", borderRadius: "999px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", fontSize: "12px", color: "#9a9fb1" }}>
                        <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#4860ff", boxShadow: "0 0 10px #4860ff" }} />
                        {"Tone"}
                        <span data-emo-tag="1" style={{ color: "#e9eef8", fontWeight: "500" }}>
                          {"Calm"}
                        </span>
                      </div>
                      {" "}
                      <svg viewBox="0 0 300 120" fill="none" style={{ width: "100%", height: "auto", overflow: "visible" }}>
                        <defs>
                          <linearGradient id="emoG" x1="0" x2="1" y1="0" y2="0">
                            <stop offset="0" stopColor="#4860ff" stopOpacity="0" />
                            <stop offset="0.5" stopColor="#cfdcf3" />
                            <stop offset="1" stopColor="#4860ff" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                        <path data-emo-path="1" data-j="1" d="M0 60 L300 60" stroke="#4860ff" strokeOpacity="0.45" strokeWidth="1.5" strokeLinecap="round" />
                        <path data-emo-path="1" data-j="0" d="M0 60 L300 60" stroke="#4860ff" strokeOpacity="0.3" strokeWidth="8" strokeLinecap="round" />
                        <path data-emo-path="1" data-j="0" d="M0 60 L300 60" stroke="url(#emoG)" strokeWidth="2.5" strokeLinecap="round" />
                      </svg>
                      {" "}
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ position: "relative", padding: "0 clamp(20px, 2cqw, 28px) clamp(22px, 2cqw, 28px)", display: "flex", flexDirection: "column", gap: "8px" }}>
                    {" "}
                    <h3 style={{ margin: "0", fontSize: "clamp(18px, 1.45cqw, 21px)", fontWeight: "500", lineHeight: "1.2", letterSpacing: "-0.03em", color: "#e9eef8" }}>
                      {"Emotion-Aware Dubbing"}
                    </h3>
                    {" "}
                    <p style={{ margin: "0", maxWidth: "30em", fontSize: "14px", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                      {"Laughter, tension and whispers carry over, so the performance lands the same way in every language."}
                    </p>
                    {" "}
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
              <div data-rv="3" style={{ flex: "1 1 250px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,60px,0)", filter: "blur(6px)", transition: "opacity 0.9s cubic-bezier(0.2,0.7,0.2,1), transform 1.1s cubic-bezier(0.2,0.7,0.2,1), filter 0.9s cubic-bezier(0.2,0.7,0.2,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", overflow: "hidden", boxSizing: "border-box", minHeight: "clamp(380px, 31cqw, 420px)", display: "flex", flexDirection: "column", isolation: "isolate", borderRadius: "22px", background: "radial-gradient(75% 38% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.5s cubic-bezier(0.2,0.7,0.2,1), border-color 0.4s ease" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "relative", flex: "1", minHeight: "210px", display: "flex", alignItems: "center", justifyContent: "center", padding: "30px clamp(20px, 2cqw, 28px) 10px" }}>
                    {" "}
                    <div style={{ width: "100%", maxWidth: "320px", display: "flex", flexDirection: "column", gap: "8px" }}>
                      {" "}
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", color: "#9a9fb1" }}>
                        <span>
                          {"Original · EN"}
                        </span>
                        <span style={{ color: "#cfdcf3" }}>
                          {"Your voice"}
                        </span>
                      </div>
                      {" "}
                      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", height: "48px" }}>
                        <span data-id-bar="1" data-i="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="3" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="4" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="5" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="6" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="7" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="8" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="9" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="10" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="11" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="12" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="13" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="14" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="15" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="16" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="17" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="18" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="19" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="20" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="21" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="22" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="23" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="24" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="25" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="26" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="27" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="28" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="29" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="30" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="31" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "rgba(207,220,243,0.7)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                      </div>
                      {" "}
                      <div style={{ height: "1px", background: "linear-gradient(90deg, rgba(140,235,255,0), rgba(140,235,255,0.7), rgba(140,235,255,0))" }} />
                      {" "}
                      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", height: "48px" }}>
                        <span data-id-bar="1" data-i="0" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="1" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="2" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="3" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="4" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="5" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="6" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="7" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="8" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="9" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="10" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="11" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="12" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="13" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="14" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="15" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="16" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="17" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="18" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="19" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="20" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="21" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="22" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="23" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="24" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="25" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="26" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="27" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="28" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="29" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="30" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                        <span data-id-bar="1" data-i="31" style={{ width: "4px", height: "100%", borderRadius: "2px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 0%", transform: "scaleY(0.4)" }} />
                      </div>
                      {" "}
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", color: "#9a9fb1" }}>
                        <span>
                          {"Dubbed · ES"}
                        </span>
                        <span style={{ color: "#a9c6ff" }}>
                          {"Still you"}
                        </span>
                      </div>
                      {" "}
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ position: "relative", padding: "0 clamp(20px, 2cqw, 28px) clamp(22px, 2cqw, 28px)", display: "flex", flexDirection: "column", gap: "8px" }}>
                    {" "}
                    <h3 style={{ margin: "0", fontSize: "clamp(18px, 1.45cqw, 21px)", fontWeight: "500", lineHeight: "1.2", letterSpacing: "-0.03em", color: "#e9eef8" }}>
                      {"Voice Identity Preservation"}
                    </h3>
                    {" "}
                    <p style={{ margin: "0", maxWidth: "30em", fontSize: "14px", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                      {"Your dubbed voice keeps your tone and timbre, so your audience still knows it’s you."}
                    </p>
                    {" "}
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
            </div>
            {" "}
            <div style={{ display: "flex", flexWrap: "wrap", gap: "clamp(14px, 1.4cqw, 20px)" }}>
              {" "}
              <div data-rv="4" style={{ flex: "7 1 480px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,60px,0)", filter: "blur(6px)", transition: "opacity 0.9s cubic-bezier(0.2,0.7,0.2,1), transform 1.1s cubic-bezier(0.2,0.7,0.2,1), filter 0.9s cubic-bezier(0.2,0.7,0.2,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", overflow: "hidden", boxSizing: "border-box", minHeight: "clamp(380px, 31cqw, 420px)", display: "flex", flexDirection: "column", isolation: "isolate", borderRadius: "22px", background: "radial-gradient(75% 38% at 62% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.5s cubic-bezier(0.2,0.7,0.2,1), border-color 0.4s ease" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "relative", flex: "1", minHeight: "210px", display: "flex", alignItems: "center", justifyContent: "center", padding: "30px clamp(20px, 2cqw, 28px) 10px" }}>
                    {" "}
                    <div style={{ width: "100%", display: "flex", gap: "12px" }}>
                      {" "}
                      <div style={{ display: "flex", flexDirection: "column", gap: "10px", paddingTop: "26px" }}>
                        <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", height: "40px", width: "42px", borderRadius: "10px", fontSize: "11.5px", fontWeight: "500", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "#9a9fb1" }}>
                          {"EN"}
                        </span>
                        <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", height: "40px", width: "42px", borderRadius: "10px", fontSize: "11.5px", fontWeight: "500", background: "rgba(72,96,255,0.2)", border: "1px solid rgba(72,96,255,0.5)", color: "#cfdcf3" }}>
                          {"ES"}
                        </span>
                      </div>
                      {" "}
                      <div style={{ position: "relative", flex: "1", minWidth: "0", display: "flex", flexDirection: "column", gap: "10px", paddingBottom: "30px" }}>
                        {" "}
                        <div style={{ display: "flex", justifyContent: "space-between", height: "16px", fontSize: "10.5px", color: "#6f7790", fontVariantNumeric: "tabular-nums" }}>
                          <span>
                            {"00:00"}
                          </span>
                          <span>
                            {"00:06"}
                          </span>
                          <span>
                            {"00:12"}
                          </span>
                          <span>
                            {"00:18"}
                          </span>
                          <span>
                            {"00:24"}
                          </span>
                        </div>
                        {" "}
                        <div style={{ position: "relative", height: "40px", borderRadius: "10px", background: "rgba(255,255,255,0.035)", border: "1px solid rgba(255,255,255,0.06)" }}>
                          <span data-sync-seg="1" data-s="3" data-e="20" style={{ position: "absolute", top: "5px", bottom: "5px", left: "3%", width: "17%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(207,220,243,0.55) 0 2px, rgba(207,220,243,0) 2px 5px), rgba(207,220,243,0.1)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="24" data-e="44" style={{ position: "absolute", top: "5px", bottom: "5px", left: "24%", width: "20%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(207,220,243,0.55) 0 2px, rgba(207,220,243,0) 2px 5px), rgba(207,220,243,0.1)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="49" data-e="62" style={{ position: "absolute", top: "5px", bottom: "5px", left: "49%", width: "13%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(207,220,243,0.55) 0 2px, rgba(207,220,243,0) 2px 5px), rgba(207,220,243,0.1)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="67" data-e="89" style={{ position: "absolute", top: "5px", bottom: "5px", left: "67%", width: "22%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(207,220,243,0.55) 0 2px, rgba(207,220,243,0) 2px 5px), rgba(207,220,243,0.1)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="93" data-e="99" style={{ position: "absolute", top: "5px", bottom: "5px", left: "93%", width: "6%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(207,220,243,0.55) 0 2px, rgba(207,220,243,0) 2px 5px), rgba(207,220,243,0.1)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                        </div>
                        {" "}
                        <div style={{ position: "relative", height: "40px", borderRadius: "10px", background: "rgba(255,255,255,0.035)", border: "1px solid rgba(255,255,255,0.06)" }}>
                          <span data-sync-seg="1" data-s="3" data-e="20" style={{ position: "absolute", top: "5px", bottom: "5px", left: "3%", width: "17%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(255,255,255,0.55) 0 2px, rgba(255,255,255,0) 2px 5px), linear-gradient(180deg, #8ce6ff, #4860ff)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="24" data-e="44" style={{ position: "absolute", top: "5px", bottom: "5px", left: "24%", width: "20%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(255,255,255,0.55) 0 2px, rgba(255,255,255,0) 2px 5px), linear-gradient(180deg, #8ce6ff, #4860ff)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="49" data-e="62" style={{ position: "absolute", top: "5px", bottom: "5px", left: "49%", width: "13%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(255,255,255,0.55) 0 2px, rgba(255,255,255,0) 2px 5px), linear-gradient(180deg, #8ce6ff, #4860ff)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="67" data-e="89" style={{ position: "absolute", top: "5px", bottom: "5px", left: "67%", width: "22%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(255,255,255,0.55) 0 2px, rgba(255,255,255,0) 2px 5px), linear-gradient(180deg, #8ce6ff, #4860ff)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                          <span data-sync-seg="1" data-s="93" data-e="99" style={{ position: "absolute", top: "5px", bottom: "5px", left: "93%", width: "6%", borderRadius: "7px", background: "repeating-linear-gradient(90deg, rgba(255,255,255,0.55) 0 2px, rgba(255,255,255,0) 2px 5px), linear-gradient(180deg, #8ce6ff, #4860ff)", opacity: "0.5", transition: "opacity 0.25s ease" }} />
                        </div>
                        {" "}
                        <div data-sync-head="1" style={{ position: "absolute", top: "22px", bottom: "24px", left: "0", width: "0", pointerEvents: "none" }}>
                          <div style={{ position: "absolute", top: "0", bottom: "0", left: "-1px", width: "2px", borderRadius: "1px", background: "#8ce6ff", boxShadow: "0 0 12px #4860ff" }} />
                          <span data-sync-tc="1" style={{ position: "absolute", bottom: "-26px", left: "0", transform: "translateX(-50%)", padding: "3px 8px", borderRadius: "6px", background: "#4860ff", fontSize: "10.5px", color: "#ffffff", fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }}>
                            {"00:00.0"}
                          </span>
                        </div>
                        {" "}
                      </div>
                      {" "}
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ position: "relative", padding: "0 clamp(20px, 2cqw, 28px) clamp(22px, 2cqw, 28px)", display: "flex", flexDirection: "column", gap: "8px" }}>
                    {" "}
                    <h3 style={{ margin: "0", fontSize: "clamp(18px, 1.45cqw, 21px)", fontWeight: "500", lineHeight: "1.2", letterSpacing: "-0.03em", color: "#e9eef8" }}>
                      {"Dialogue Synchronization"}
                    </h3>
                    {" "}
                    <p style={{ margin: "0", maxWidth: "30em", fontSize: "14px", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                      {"Every dubbed line is timed to the speaker’s pace and pauses, so speech stays in step with what’s on screen."}
                    </p>
                    {" "}
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
              <div data-rv="5" style={{ flex: "5 1 340px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,60px,0)", filter: "blur(6px)", transition: "opacity 0.9s cubic-bezier(0.2,0.7,0.2,1), transform 1.1s cubic-bezier(0.2,0.7,0.2,1), filter 0.9s cubic-bezier(0.2,0.7,0.2,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", overflow: "hidden", boxSizing: "border-box", minHeight: "clamp(380px, 31cqw, 420px)", display: "flex", flexDirection: "column", isolation: "isolate", borderRadius: "22px", background: "radial-gradient(75% 38% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.5s cubic-bezier(0.2,0.7,0.2,1), border-color 0.4s ease" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <div aria-hidden="true" style={{ position: "relative", flex: "1", minHeight: "210px", display: "flex", alignItems: "center", justifyContent: "center", padding: "30px clamp(20px, 2cqw, 28px) 10px" }}>
                    {" "}
                    <div style={{ width: "100%", maxWidth: "360px", display: "flex", alignItems: "flex-end", gap: "10px" }}>
                      <div style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
                        <span style={{ display: "inline-flex", alignItems: "center", height: "22px", fontSize: "11px", color: "#6f7790" }}>
                          {"Kept"}
                        </span>
                        <div style={{ boxSizing: "border-box", width: "100%", height: "116px", display: "flex", alignItems: "flex-end", justifyContent: "center", gap: "4px", padding: "12px 6px", borderRadius: "12px", background: "rgba(255,255,255,0.035)", border: "1px solid rgba(255,255,255,0.07)" }}>
                          <span data-bg-bar="1" data-g="0" data-i="0" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="0" data-i="1" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="0" data-i="2" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="0" data-i="3" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="0" data-i="4" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        </div>
                        <span style={{ fontSize: "11.5px", color: "#9a9fb1" }}>
                          {"Music"}
                        </span>
                      </div>
                      <div style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
                        <span style={{ display: "inline-flex", alignItems: "center", height: "22px", fontSize: "11px", color: "#6f7790" }}>
                          {"Kept"}
                        </span>
                        <div style={{ boxSizing: "border-box", width: "100%", height: "116px", display: "flex", alignItems: "flex-end", justifyContent: "center", gap: "4px", padding: "12px 6px", borderRadius: "12px", background: "rgba(255,255,255,0.035)", border: "1px solid rgba(255,255,255,0.07)" }}>
                          <span data-bg-bar="1" data-g="1" data-i="0" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="1" data-i="1" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="1" data-i="2" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="1" data-i="3" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="1" data-i="4" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        </div>
                        <span style={{ fontSize: "11.5px", color: "#9a9fb1" }}>
                          {"Ambience"}
                        </span>
                      </div>
                      <div style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
                        <span style={{ display: "inline-flex", alignItems: "center", height: "22px", fontSize: "11px", color: "#6f7790" }}>
                          {"Kept"}
                        </span>
                        <div style={{ boxSizing: "border-box", width: "100%", height: "116px", display: "flex", alignItems: "flex-end", justifyContent: "center", gap: "4px", padding: "12px 6px", borderRadius: "12px", background: "rgba(255,255,255,0.035)", border: "1px solid rgba(255,255,255,0.07)" }}>
                          <span data-bg-bar="1" data-g="2" data-i="0" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="2" data-i="1" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="2" data-i="2" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="2" data-i="3" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="2" data-i="4" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "rgba(207,220,243,0.5)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        </div>
                        <span style={{ fontSize: "11.5px", color: "#9a9fb1" }}>
                          {"Effects"}
                        </span>
                      </div>
                      <div style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
                        <span data-bg-lang="1" style={{ display: "inline-flex", alignItems: "center", height: "22px", padding: "0 9px", borderRadius: "999px", background: "#4860ff", fontSize: "11px", fontWeight: "500", color: "#ffffff", boxShadow: "0 6px 16px -6px rgba(72,96,255,0.9)" }}>
                          {"ES"}
                        </span>
                        <div style={{ boxSizing: "border-box", width: "100%", height: "116px", display: "flex", alignItems: "flex-end", justifyContent: "center", gap: "4px", padding: "12px 6px", borderRadius: "12px", background: "rgba(72,96,255,0.14)", border: "1px solid rgba(72,96,255,0.5)" }}>
                          <span data-bg-bar="1" data-g="3" data-i="0" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="3" data-i="1" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="3" data-i="2" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="3" data-i="3" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                          <span data-bg-bar="1" data-g="3" data-i="4" style={{ width: "6px", height: "100%", borderRadius: "3px", background: "linear-gradient(180deg, #8ce6ff, #4860ff)", transformOrigin: "50% 100%", transform: "scaleY(0.4)" }} />
                        </div>
                        <span style={{ fontSize: "11.5px", color: "#cfdcf3" }}>
                          {"Voice"}
                        </span>
                      </div>
                      {" "}
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ position: "relative", padding: "0 clamp(20px, 2cqw, 28px) clamp(22px, 2cqw, 28px)", display: "flex", flexDirection: "column", gap: "8px" }}>
                    {" "}
                    <h3 style={{ margin: "0", fontSize: "clamp(18px, 1.45cqw, 21px)", fontWeight: "500", lineHeight: "1.2", letterSpacing: "-0.03em", color: "#e9eef8" }}>
                      {"Background Audio Preservation"}
                    </h3>
                    {" "}
                    <p style={{ margin: "0", maxWidth: "30em", fontSize: "14px", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                      {"Music, ambience and sound effects stay exactly as you mixed them. Only the voice changes."}
                    </p>
                    {" "}
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
            </div>
            {" "}
          </div>
          {" "}
        </section>
        {" "}
        <section ref={v.howRef} id="how-it-works" data-screen-label="How it works" aria-label="How it works" style={{ position: "relative", height: "260svh", background: "#080913" }}>
          {" "}
          <div ref={v.howTrackRef} style={{ position: "sticky", top: "0", height: "100svh", overflow: "hidden", containerType: "inline-size" }}>
            {" "}
            <div data-hw-glow="1" aria-hidden="true" style={{ position: "absolute", left: "50%", top: "58%", width: "min(90cqw, 1100px)", height: "min(70svh, 720px)", transform: "translate(-50%,-50%)", pointerEvents: "none", opacity: "0.4", background: "radial-gradient(closest-side, rgba(72,96,255,0.22) 0%, rgba(72,96,255,0.07) 45%, rgba(72,96,255,0) 100%)" }} />
            {" "}
            <div data-hw-big="1" aria-hidden="true" style={{ position: "absolute", left: "50%", bottom: "-3.2cqw", transform: "translate3d(-50%,0,0)", whiteSpace: "nowrap", fontSize: "17cqw", lineHeight: "1", fontWeight: "500", letterSpacing: "-0.06em", background: "linear-gradient(180deg, rgba(150,178,240,0.2) 0%, rgba(150,178,240,0.07) 38%, rgba(150,178,240,0.015) 62%, rgba(150,178,240,0) 76%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", pointerEvents: "none" }}>
              {"How it works"}
            </div>
            {" "}
            <div data-hw-logo="1" aria-hidden="true" style={{ position: "absolute", left: "50%", top: "58%", width: "min(34cqw, 52svh, 500px)", minWidth: "260px", transform: "translate(-50%,-50%)", pointerEvents: "none" }}>
              {" "}
              <svg viewBox="40 20 268 170" style={{ width: "100%", height: "auto", display: "block", overflow: "visible" }} strokeLinecap="round">
                <g stroke="#ffffff" strokeWidth="7">
                  {(v.hwSide || []).map((s, $index) => (
                    <React.Fragment key={$index}>
                      <line data-hw-s="1" data-i={s.i} data-m={s.m} data-l={s.l} x1={s.x} x2={s.x} y1={s.y1} y2={s.y2} strokeOpacity={s.op} />
                    </React.Fragment>
                  ))}
                </g>
              </svg>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", left: "12%", right: "12%", top: "18%", bottom: "18%", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(72,96,255,0.42) 0%, rgba(72,96,255,0.16) 55%, rgba(72,96,255,0) 100%)" }} />
              <svg viewBox="40 20 268 170" style={{ position: "absolute", inset: "0", width: "100%", height: "auto", display: "block", overflow: "visible" }} fill="#ffffff" stroke="#ffffff" strokeWidth="11" strokeLinecap="round">
                <circle cx="60" cy="112" r="6.5" stroke="none" />
                <circle cx="287" cy="112" r="6.5" stroke="none" />
                {(v.hwLogo || []).map((l, $index) => (
                  <React.Fragment key={$index}>
                    <line data-hw-l="1" data-c="1" data-i={l.i} data-m={l.m} data-l={l.l} x1={l.x} x2={l.x} y1={l.y1} y2={l.y2} />
                  </React.Fragment>
                ))}
              </svg>
              {" "}
            </div>
            {" "}
            <div data-hw-title="1" style={{ position: "absolute", left: "0", right: "0", top: "clamp(72px, 12svh, 130px)", display: "flex", flexDirection: "column", alignItems: "center", padding: "0 20px", textAlign: "center", pointerEvents: "none" }}>
              {" "}
              <h2 style={{ margin: "0", display: "flex", flexDirection: "column", alignItems: "center", fontSize: "clamp(32px, 4.6cqw, 72px)", fontWeight: "500", lineHeight: "1.04", letterSpacing: "-0.045em" }}>
                {" "}
                <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #a7b4d3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                  {"From One Upload"}
                </span>
                {" "}
                <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #a7b4d3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                  {"To A Global Release."}
                </span>
                {" "}
              </h2>
              {" "}
            </div>
            {" "}
            <article data-hw-card="1" style={{ position: "absolute", top: "0", left: "7%", width: "min(23%, 330px)", minWidth: "250px", aspectRatio: "1 / 1", boxSizing: "border-box", transform: "translate3d(0,120svh,0)", willChange: "transform", display: "flex", flexDirection: "column", padding: "clamp(22px, 2cqw, 30px)", borderRadius: "22px", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
              {" "}
              <div style={{ position: "relative", width: "52px", height: "52px", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)", fontSize: "14px", fontWeight: "500", letterSpacing: "0.02em", color: "#e9eef8" }}>
                {"01"}
              </div>
              {" "}
              <div style={{ position: "relative", marginTop: "auto", display: "flex", flexDirection: "column", gap: "12px" }}>
                {" "}
                <h3 style={{ margin: "0", fontSize: "clamp(20px, 1.7cqw, 25px)", fontWeight: "500", lineHeight: "1.18", letterSpacing: "-0.03em", color: "#ffffff", textWrap: "balance" }}>
                  {"Upload your video"}
                </h3>
                {" "}
                <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.55", color: "#b3b9ca", textWrap: "pretty" }}>
                  {"Drop in a file or paste a link. AutoDub separates dialogue, music and effects in seconds."}
                </p>
                {" "}
              </div>
              {" "}
            </article>
            {" "}
            <article data-hw-card="1" style={{ position: "absolute", top: "0", left: "69%", width: "min(23%, 330px)", minWidth: "250px", aspectRatio: "1 / 1", boxSizing: "border-box", transform: "translate3d(0,120svh,0)", willChange: "transform", display: "flex", flexDirection: "column", padding: "clamp(22px, 2cqw, 30px)", borderRadius: "22px", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 62% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
              {" "}
              <div style={{ position: "relative", width: "52px", height: "52px", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)", fontSize: "14px", fontWeight: "500", letterSpacing: "0.02em", color: "#e9eef8" }}>
                {"02"}
              </div>
              {" "}
              <div style={{ position: "relative", marginTop: "auto", display: "flex", flexDirection: "column", gap: "12px" }}>
                {" "}
                <h3 style={{ margin: "0", fontSize: "clamp(20px, 1.7cqw, 25px)", fontWeight: "500", lineHeight: "1.18", letterSpacing: "-0.03em", color: "#ffffff", textWrap: "balance" }}>
                  {"Transcribe & translate"}
                </h3>
                {" "}
                <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.55", color: "#b3b9ca", textWrap: "pretty" }}>
                  {"Every line is transcribed, timed and translated with context, so idioms and tone survive."}
                </p>
                {" "}
              </div>
              {" "}
            </article>
            {" "}
            <article data-hw-card="1" style={{ position: "absolute", top: "0", left: "13%", width: "min(23%, 330px)", minWidth: "250px", aspectRatio: "1 / 1", boxSizing: "border-box", transform: "translate3d(0,120svh,0)", willChange: "transform", display: "flex", flexDirection: "column", padding: "clamp(22px, 2cqw, 30px)", borderRadius: "22px", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
              {" "}
              <div style={{ position: "relative", width: "52px", height: "52px", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)", fontSize: "14px", fontWeight: "500", letterSpacing: "0.02em", color: "#e9eef8" }}>
                {"03"}
              </div>
              {" "}
              <div style={{ position: "relative", marginTop: "auto", display: "flex", flexDirection: "column", gap: "12px" }}>
                {" "}
                <h3 style={{ margin: "0", fontSize: "clamp(20px, 1.7cqw, 25px)", fontWeight: "500", lineHeight: "1.18", letterSpacing: "-0.03em", color: "#ffffff", textWrap: "balance" }}>
                  {"Clone & perform"}
                </h3>
                {" "}
                <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.55", color: "#b3b9ca", textWrap: "pretty" }}>
                  {"Each speaker's voice is recreated in the target language, with identity and emotion intact."}
                </p>
                {" "}
              </div>
              {" "}
            </article>
            {" "}
            <article data-hw-card="1" style={{ position: "absolute", top: "0", left: "63%", width: "min(23%, 330px)", minWidth: "250px", aspectRatio: "1 / 1", boxSizing: "border-box", transform: "translate3d(0,120svh,0)", willChange: "transform", display: "flex", flexDirection: "column", padding: "clamp(22px, 2cqw, 30px)", borderRadius: "22px", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 62% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
              {" "}
              <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
              {" "}
              <div style={{ position: "relative", width: "52px", height: "52px", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)", fontSize: "14px", fontWeight: "500", letterSpacing: "0.02em", color: "#e9eef8" }}>
                {"04"}
              </div>
              {" "}
              <div style={{ position: "relative", marginTop: "auto", display: "flex", flexDirection: "column", gap: "12px" }}>
                {" "}
                <h3 style={{ margin: "0", fontSize: "clamp(20px, 1.7cqw, 25px)", fontWeight: "500", lineHeight: "1.18", letterSpacing: "-0.03em", color: "#ffffff", textWrap: "balance" }}>
                  {"Sync & publish"}
                </h3>
                {" "}
                <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.55", color: "#b3b9ca", textWrap: "pretty" }}>
                  {"Lips, pauses and timing are matched to the picture. Export or publish straight to your channels."}
                </p>
                {" "}
              </div>
              {" "}
            </article>
            {" "}
          </div>
          {" "}
        </section>
        {" "}
        <section ref={v.ucRef} id="use-cases" data-screen-label="Use cases" aria-label="Use cases" style={{ position: "relative", background: "#080913", padding: "clamp(60px, 6.2cqw, 100px) clamp(16px, 3cqw, 56px) clamp(32px, 3.2cqw, 52px)", containerType: "inline-size" }}>
          {" "}
          {v.ucDesk ? (
            <>
              {" "}
              <div data-uc-stage="1" style={{ position: "relative", width: "min(100%, 1440px)", margin: "0 auto", aspectRatio: "1.42 / 1", containerType: "inline-size" }}>
                {" "}
                <div aria-hidden="true" style={{ position: "absolute", inset: "0", pointerEvents: "none", background: "radial-gradient(50% 36% at 50% 70%, rgba(72,96,255,0.09) 0%, rgba(72,96,255,0.03) 45%, rgba(72,96,255,0) 100%)" }} />
                {" "}
                <div style={{ position: "absolute", left: "2.4%", right: "2.4%", top: "3.6%", display: "flex", justifyContent: "space-between", gap: "16px", fontSize: "clamp(11px, 1cqw, 14px)", letterSpacing: "0.02em", color: "#7f88a3" }}>
                  {" "}
                  <span>
                    {"Use cases"}
                  </span>
                  <span>
                    {"Who it's for"}
                  </span>
                  {" "}
                </div>
                {" "}
                <h2 style={{ position: "absolute", zIndex: "0", left: "0", right: "0", top: "5.8%", margin: "0", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", fontSize: "clamp(32px, 4.9cqw, 72px)", fontWeight: "500", lineHeight: "1.04", letterSpacing: "-0.045em" }}>
                  {" "}
                  <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #c3cce3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                    {"Made for Every Creator,"}
                  </span>
                  {" "}
                  <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #a7b4d3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                    {"Every Team"}
                  </span>
                  {" "}
                  <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #98a6c8 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                    {"And Every Voice."}
                  </span>
                  {" "}
                </h2>
                {" "}
                <div style={{ position: "absolute", zIndex: "1", left: "13.4%", top: "15.9%", width: "22cqw", height: "31cqw", transform: "translateX(-50%) rotate(10deg)" }}>
                  {" "}
                  <div data-uc="0" style={{ position: "absolute", inset: "0", opacity: "0", transform: "translate3d(0,70%,0) rotate(-5deg)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                    {" "}
                    <article data-uc-card="1" style={{ position: "absolute", inset: "0", boxSizing: "border-box", transition: "transform 0.55s cubic-bezier(0.2,0.8,0.2,1)", display: "flex", flexDirection: "column", gap: "2.6cqw", padding: "2.1cqw", borderRadius: "clamp(16px, 1.8cqw, 26px)", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
                      {" "}
                      <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                      <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                      {" "}
                      <div style={{ position: "relative", width: "3.6cqw", height: "3.6cqw", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)" }}>
                        <svg viewBox="0 0 24 24" style={{ width: "46%", height: "46%" }} fill="none" stroke="#e9eef8" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
                          <path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5zM10 9l5 3-5 3z" />
                        </svg>
                      </div>
                      {" "}
                      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: "0.9cqw" }}>
                        {" "}
                        <h3 style={{ margin: "0", fontSize: "2.3cqw", fontWeight: "500", lineHeight: "1.1", letterSpacing: "-0.035em", color: "#ffffff", textWrap: "balance" }}>
                          {"YouTube & Independent Creators"}
                        </h3>
                        {" "}
                        <p style={{ margin: "0", fontSize: "max(12px, 1.12cqw)", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                          {"Publish every upload in new languages without re-recording a word, and grow audiences you couldn't reach before."}
                        </p>
                        {" "}
                      </div>
                      {" "}
                    </article>
                    {" "}
                  </div>
                  {" "}
                </div>
                {" "}
                <div style={{ position: "absolute", zIndex: "2", left: "28.5%", top: "50.9%", width: "22cqw", height: "31cqw", transform: "translateX(-50%) rotate(-6deg)" }}>
                  {" "}
                  <div data-uc="1" style={{ position: "absolute", inset: "0", opacity: "0", transform: "translate3d(0,70%,0) rotate(3deg)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                    {" "}
                    <article data-uc-card="1" style={{ position: "absolute", inset: "0", boxSizing: "border-box", transition: "transform 0.55s cubic-bezier(0.2,0.8,0.2,1)", display: "flex", flexDirection: "column", gap: "2.6cqw", padding: "2.1cqw", borderRadius: "clamp(16px, 1.8cqw, 26px)", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
                      {" "}
                      <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                      <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                      {" "}
                      <div style={{ position: "relative", width: "3.6cqw", height: "3.6cqw", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)" }}>
                        <svg viewBox="0 0 24 24" style={{ width: "46%", height: "46%" }} fill="none" stroke="#e9eef8" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
                          <path d="M3 9l9-4 9 4-9 4zM7 11v4.5c1.5 1.3 3.2 2 5 2s3.5-.7 5-2V11M21 9v5" />
                        </svg>
                      </div>
                      {" "}
                      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: "0.9cqw" }}>
                        {" "}
                        <h3 style={{ margin: "0", fontSize: "2.3cqw", fontWeight: "500", lineHeight: "1.1", letterSpacing: "-0.035em", color: "#ffffff", textWrap: "balance" }}>
                          {"Education & Online Learning"}
                        </h3>
                        {" "}
                        <p data-uc-tail="2" style={{ margin: "0", fontSize: "max(12px, 1.12cqw)", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                          {"Turn one course into many. Lessons sound native, so learners focus on the material, not the accent."}
                        </p>
                        {" "}
                      </div>
                      {" "}
                    </article>
                    {" "}
                  </div>
                  {" "}
                </div>
                {" "}
                <div style={{ position: "absolute", zIndex: "3", left: "49.5%", top: "33.4%", width: "22cqw", height: "31cqw", transform: "translateX(-50%)" }}>
                  {" "}
                  <div data-uc="2" style={{ position: "absolute", inset: "0", opacity: "0", transform: "translate3d(0,70%,0) rotate(-2deg)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                    {" "}
                    <article data-uc-card="1" style={{ position: "absolute", inset: "0", boxSizing: "border-box", transition: "transform 0.55s cubic-bezier(0.2,0.8,0.2,1)", display: "flex", flexDirection: "column", gap: "2.6cqw", padding: "2.1cqw", borderRadius: "clamp(16px, 1.8cqw, 26px)", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
                      {" "}
                      <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                      <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                      {" "}
                      <div style={{ position: "relative", width: "3.6cqw", height: "3.6cqw", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)" }}>
                        <svg viewBox="0 0 24 24" style={{ width: "46%", height: "46%" }} fill="none" stroke="#e9eef8" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
                          <path d="M12 3a3 3 0 0 1 3 3v5a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3zM5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21" />
                        </svg>
                      </div>
                      {" "}
                      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: "0.9cqw" }}>
                        {" "}
                        <h3 style={{ margin: "0", fontSize: "2.3cqw", fontWeight: "500", lineHeight: "1.1", letterSpacing: "-0.035em", color: "#ffffff", textWrap: "balance" }}>
                          {"Podcasts & Interviews"}
                        </h3>
                        {" "}
                        <p style={{ margin: "0", fontSize: "max(12px, 1.12cqw)", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                          {"Every host and guest keeps their own voice, so conversations stay natural in every language."}
                        </p>
                        {" "}
                      </div>
                      {" "}
                    </article>
                    {" "}
                  </div>
                  {" "}
                </div>
                {" "}
                <div style={{ position: "absolute", zIndex: "5", left: "68.5%", top: "49%", width: "22cqw", height: "31cqw", transform: "translateX(-50%) rotate(12deg)" }}>
                  {" "}
                  <div data-uc="3" style={{ position: "absolute", inset: "0", opacity: "0", transform: "translate3d(0,70%,0) rotate(5deg)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                    {" "}
                    <article data-uc-card="1" style={{ position: "absolute", inset: "0", boxSizing: "border-box", transition: "transform 0.55s cubic-bezier(0.2,0.8,0.2,1)", display: "flex", flexDirection: "column", gap: "2.6cqw", padding: "2.1cqw", borderRadius: "clamp(16px, 1.8cqw, 26px)", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
                      {" "}
                      <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                      <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                      {" "}
                      <div style={{ position: "relative", width: "3.6cqw", height: "3.6cqw", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)" }}>
                        <svg viewBox="0 0 24 24" style={{ width: "46%", height: "46%" }} fill="none" stroke="#e9eef8" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
                          <path d="M4 5h16v14H4zM8 5v14M16 5v14M4 9.5h4M4 14.5h4M16 9.5h4M16 14.5h4" />
                        </svg>
                      </div>
                      {" "}
                      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: "0.9cqw" }}>
                        {" "}
                        <h3 style={{ margin: "0", fontSize: "2.3cqw", fontWeight: "500", lineHeight: "1.1", letterSpacing: "-0.035em", color: "#ffffff", textWrap: "balance" }}>
                          {"Documentaries & Media Production"}
                        </h3>
                        {" "}
                        <p style={{ margin: "0", fontSize: "max(12px, 1.12cqw)", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                          {"Broadcast-ready dubs with timing and emotion matched to the cut, at a fraction of studio cost."}
                        </p>
                        {" "}
                      </div>
                      {" "}
                    </article>
                    {" "}
                  </div>
                  {" "}
                </div>
                {" "}
                <div style={{ position: "absolute", zIndex: "4", left: "87%", top: "14%", width: "22cqw", height: "31cqw", transform: "translateX(-50%) rotate(-10deg)" }}>
                  {" "}
                  <div data-uc="4" style={{ position: "absolute", inset: "0", opacity: "0", transform: "translate3d(0,70%,0) rotate(-4deg)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                    {" "}
                    <article data-uc-card="1" style={{ position: "absolute", inset: "0", boxSizing: "border-box", transition: "transform 0.55s cubic-bezier(0.2,0.8,0.2,1)", display: "flex", flexDirection: "column", gap: "2.6cqw", padding: "2.1cqw", borderRadius: "clamp(16px, 1.8cqw, 26px)", overflow: "hidden", isolation: "isolate", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
                      {" "}
                      <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                      <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                      {" "}
                      <div style={{ position: "relative", width: "3.6cqw", height: "3.6cqw", flex: "none", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.18), 0 10px 24px -10px rgba(0,0,0,0.8)" }}>
                        <svg viewBox="0 0 24 24" style={{ width: "46%", height: "46%" }} fill="none" stroke="#e9eef8" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
                          <path d="M4 8h16v11H4zM9 8V5.5h6V8M4 13h16" />
                        </svg>
                      </div>
                      {" "}
                      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: "0.9cqw" }}>
                        {" "}
                        <h3 style={{ margin: "0", fontSize: "2.3cqw", fontWeight: "500", lineHeight: "1.1", letterSpacing: "-0.035em", color: "#ffffff", textWrap: "balance" }}>
                          {"Businesses & Corporate Training"}
                        </h3>
                        {" "}
                        <p style={{ margin: "0", fontSize: "max(12px, 1.12cqw)", lineHeight: "1.5", color: "#b3b9ca", textWrap: "pretty" }}>
                          {"Roll out onboarding and training to global teams in days, with one consistent, on-brand voice."}
                        </p>
                        {" "}
                      </div>
                      {" "}
                    </article>
                    {" "}
                  </div>
                  {" "}
                </div>
                {" "}
              </div>
              {" "}
            </>
          ) : null}
          {" "}
          {v.ucStack ? (
            <>
              {" "}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "28px" }}>
                {" "}
                <h2 style={{ margin: "0", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", fontSize: "clamp(32px, 9cqw, 48px)", fontWeight: "500", lineHeight: "1.04", letterSpacing: "-0.045em" }}>
                  {" "}
                  <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #c3cce3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                    {"Made for Every Creator,"}
                  </span>
                  {" "}
                  <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #a7b4d3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                    {"Every Team"}
                  </span>
                  {" "}
                  <span style={{ background: "linear-gradient(180deg, #ffffff 30%, #98a6c8 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent" }}>
                    {"And Every Voice."}
                  </span>
                  {" "}
                </h2>
                {" "}
                <div style={{ width: "100%", maxWidth: "880px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 320px), 1fr))", gap: "18px" }}>
                  {" "}
                  {(v.ucCases || []).map((c, $index) => (
                    <React.Fragment key={$index}>
                      {" "}
                      <div data-uc={$index} style={{ opacity: "0", transform: "translate3d(0,70px,0)", transition: "opacity 0.45s ease, transform 0.7s cubic-bezier(0.16,0.84,0.24,1)" }}>
                        {" "}
                        <article style={{ position: "relative", boxSizing: "border-box", minHeight: "240px", display: "flex", flexDirection: "column", gap: "28px", padding: "24px", borderRadius: "22px", overflow: "hidden", isolation: "isolate", transform: `rotate(${c.rot}deg)`, background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)" }}>
                          {" "}
                          <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                          <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                          {" "}
                          <div style={{ position: "relative", width: "48px", height: "48px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)" }}>
                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#e9eef8" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round">
                              <path d={c.d} />
                            </svg>
                          </div>
                          {" "}
                          <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: "10px" }}>
                            {" "}
                            <h3 style={{ margin: "0", fontSize: "24px", fontWeight: "500", lineHeight: "1.12", letterSpacing: "-0.035em", color: "#ffffff", textWrap: "balance" }}>
                              {c.title}
                            </h3>
                            {" "}
                            <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.55", color: "#b3b9ca", textWrap: "pretty" }}>
                              {c.desc}
                            </p>
                            {" "}
                          </div>
                          {" "}
                        </article>
                        {" "}
                      </div>
                      {" "}
                    </React.Fragment>
                  ))}
                  {" "}
                </div>
                {" "}
              </div>
              {" "}
            </>
          ) : null}
          {" "}
        </section>
        {" "}
        <section ref={v.prRef} id="pricing" data-screen-label="Pricing" aria-label="Pricing" style={{ position: "relative", background: "#080913", padding: "clamp(60px, 6.2cqw, 100px) clamp(16px, 3cqw, 56px) clamp(32px, 3.2cqw, 52px)" }}>
          {" "}
          <div aria-hidden="true" style={{ position: "absolute", inset: "0", pointerEvents: "none", background: "radial-gradient(45% 40% at 50% 62%, rgba(72,96,255,0.09) 0%, rgba(72,96,255,0.03) 50%, rgba(72,96,255,0) 100%)" }} />
          {" "}
          <div style={{ position: "relative", maxWidth: "1240px", margin: "0 auto", display: "flex", flexDirection: "column", alignItems: "center", gap: "clamp(22px, 2.4cqw, 32px)" }}>
            {" "}
            <h2 style={{ margin: "0", textAlign: "center", fontSize: "clamp(34px, 4.6cqw, 72px)", fontWeight: "500", lineHeight: "1.04", letterSpacing: "-0.045em", background: "linear-gradient(180deg, #ffffff 30%, #a7b4d3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", textWrap: "balance" }}>
              {"Our Pricing Plans"}
            </h2>
            {" "}
            <div role="tablist" aria-label="Billing period" style={{ display: "flex", gap: "4px", padding: "4px", borderRadius: "999px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.06)" }}>
              {" "}
              <button role="tab" aria-selected={v.prSel0} onClick={v.prPick0} style={{ height: "40px", padding: "0 clamp(11px, 3.4cqw, 18px)", border: "1.2px solid transparent", boxSizing: "border-box", borderRadius: "999px", font: "inherit", fontSize: "clamp(13px, 3.8cqw, 14px)", whiteSpace: "nowrap", cursor: "pointer", transition: "background 0.25s ease, color 0.25s ease", background: v.prTabBg0, color: v.prTabC0, boxShadow: v.prTabSh0 }}>
                {"Monthly"}
              </button>
              {" "}
              <button role="tab" aria-selected={v.prSel1} onClick={v.prPick1} style={{ height: "40px", padding: "0 clamp(11px, 3.4cqw, 18px)", border: "1.2px solid transparent", boxSizing: "border-box", borderRadius: "999px", font: "inherit", fontSize: "clamp(13px, 3.8cqw, 14px)", whiteSpace: "nowrap", cursor: "pointer", transition: "background 0.25s ease, color 0.25s ease", background: v.prTabBg1, color: v.prTabC1, boxShadow: v.prTabSh1 }}>
                {"Quarterly"}
              </button>
              {" "}
              <button role="tab" aria-selected={v.prSel2} onClick={v.prPick2} style={{ height: "40px", padding: "0 clamp(11px, 3.4cqw, 18px)", border: "1.2px solid transparent", boxSizing: "border-box", borderRadius: "999px", font: "inherit", fontSize: "clamp(13px, 3.8cqw, 14px)", whiteSpace: "nowrap", cursor: "pointer", transition: "background 0.25s ease, color 0.25s ease", background: v.prTabBg2, color: v.prTabC2, boxShadow: v.prTabSh2 }}>
                {"Yearly −20%"}
              </button>
              {" "}
            </div>
            {" "}
            <div style={{ width: "100%", marginTop: "clamp(18px, 2.4cqw, 34px)", display: "flex", flexDirection: v.prDir, justifyContent: "center", alignItems: v.prAlign, gap: "clamp(14px, 1.6cqw, 22px)" }}>
              {" "}
              <div data-pr="0" style={{ flex: "1 1 0", width: "100%", maxWidth: "390px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,70px,0)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", display: "flex", flexDirection: "column", borderRadius: "18px", overflow: "hidden", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.45s cubic-bezier(0.2,0.8,0.2,1)" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: "12px", padding: "40px 22px 18px" }}>
                    {" "}
                    <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                      <span style={{ fontSize: "13px", color: "#9aa3bd" }}>
                        {"Creator"}
                      </span>
                      <span style={{ fontSize: "clamp(24px, 2.7cqw, 32px)", fontWeight: "500", letterSpacing: "-0.04em", lineHeight: "1", whiteSpace: "nowrap", color: "#ffffff" }}>
                        {"60 min"}
                      </span>
                    </div>
                    {" "}
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "4px", textAlign: "right" }}>
                      <span style={{ fontSize: "17px", fontWeight: "500", color: "#ffffff" }}>
                        {"$"}
                        {v.pr0.price}
                        {"/month"}
                      </span>
                      <span style={{ fontSize: "12px", color: "#8a92ab" }}>
                        {v.prBill}
                      </span>
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "12px", padding: "14px 22px", background: "radial-gradient(28% 70% at 50% 128%, rgba(140,235,255,0.6) 0%, rgba(140,235,255,0) 100%), radial-gradient(48% 150% at 50% 140%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", borderTop: "1px solid rgba(255,255,255,0.08)", borderBottom: "1px solid transparent", borderImage: "linear-gradient(90deg, rgba(130,110,255,0) 0%, rgba(130,110,255,0.5) 25%, rgba(150,235,255,0.95) 50%, rgba(130,110,255,0.5) 75%, rgba(130,110,255,0) 100%) 0 0 1 0" }}>
                    {" "}
                    <span style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
                      <span style={{ fontSize: "13px", color: "#d6dcf0" }}>
                        {"From"}
                      </span>
                      <span style={{ fontSize: "26px", fontWeight: "500", letterSpacing: "-0.03em", color: "#ffffff" }}>
                        {"$"}
                        {v.pr0.per}
                      </span>
                    </span>
                    {" "}
                    <span style={{ fontSize: "13px", color: "#d6dcf0" }}>
                      {"per minute"}
                    </span>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ display: "flex", flexDirection: "column", padding: "6px 22px 0" }}>
                    {" "}
                    {(v.prRows0 || []).map((r, $index) => (
                      <React.Fragment key={$index}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: "14px" }}>
                          <span style={{ color: "#a9b0c4" }}>
                            {r.k}
                          </span>
                          <span style={{ color: "#ffffff", textAlign: "right" }}>
                            {r.v}
                          </span>
                        </div>
                      </React.Fragment>
                    ))}
                    {" "}
                    <span style={{ padding: "20px 0 4px", fontSize: "13px", letterSpacing: "0.02em", color: "#8fe3ff" }}>
                      {"Options"}
                    </span>
                    {" "}
                    {(v.prOpt0 || []).map((r, $index) => (
                      <React.Fragment key={$index}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: "14px" }}>
                          <span style={{ color: "#a9b0c4" }}>
                            {r.k}
                          </span>
                          <span style={{ color: "#ffffff", textAlign: "right" }}>
                            {r.v}
                          </span>
                        </div>
                      </React.Fragment>
                    ))}
                    {" "}
                  </div>
                  {" "}
                  <div style={{ marginTop: "auto", padding: "26px 22px 22px" }}>
                    <a className="adp11" href="#" data-soon="checkout" style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "48px", borderRadius: "12px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.14)", color: "#ffffff", fontSize: "14px", fontWeight: "500" }}>
                      {"Start with Creator"}
                    </a>
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
              <div data-pr="1" style={{ flex: "1 1 0", width: "100%", maxWidth: "390px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,70px,0)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", display: "flex", flexDirection: "column", borderRadius: "18px", overflow: "hidden", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.45s cubic-bezier(0.2,0.8,0.2,1)" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <span style={{ position: "absolute", top: "0", left: "0", padding: "6px 14px 7px", borderBottomRightRadius: "12px", background: "linear-gradient(90deg, #8ce6ff 0%, #5a78ff 100%)", fontSize: "12px", fontWeight: "500", letterSpacing: "0.01em", color: "#071030" }}>
                    {"Recommended"}
                  </span>
                  {" "}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: "12px", padding: "40px 22px 18px" }}>
                    {" "}
                    <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                      <span style={{ fontSize: "13px", color: "#b8c0d8" }}>
                        {"Pro"}
                      </span>
                      <span style={{ fontSize: "clamp(24px, 2.7cqw, 32px)", fontWeight: "500", letterSpacing: "-0.04em", lineHeight: "1", whiteSpace: "nowrap", color: "#ffffff" }}>
                        {"300 min"}
                      </span>
                    </div>
                    {" "}
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "4px", textAlign: "right" }}>
                      <span style={{ fontSize: "17px", fontWeight: "500", color: "#ffffff" }}>
                        {"$"}
                        {v.pr1.price}
                        {"/month"}
                      </span>
                      <span style={{ fontSize: "12px", color: "#9aa3bd" }}>
                        {v.prBill}
                      </span>
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "12px", padding: "14px 22px", background: "radial-gradient(28% 70% at 50% 128%, rgba(140,235,255,0.6) 0%, rgba(140,235,255,0) 100%), radial-gradient(48% 150% at 50% 140%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", borderTop: "1px solid rgba(255,255,255,0.08)", borderBottom: "1px solid transparent", borderImage: "linear-gradient(90deg, rgba(130,110,255,0) 0%, rgba(130,110,255,0.5) 25%, rgba(150,235,255,0.95) 50%, rgba(130,110,255,0.5) 75%, rgba(130,110,255,0) 100%) 0 0 1 0" }}>
                    {" "}
                    <span style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
                      <span style={{ fontSize: "13px", color: "#e4e8f6" }}>
                        {"From"}
                      </span>
                      <span style={{ fontSize: "26px", fontWeight: "500", letterSpacing: "-0.03em", color: "#ffffff" }}>
                        {"$"}
                        {v.pr1.per}
                      </span>
                    </span>
                    {" "}
                    <span style={{ fontSize: "13px", color: "#e4e8f6" }}>
                      {"per minute"}
                    </span>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ display: "flex", flexDirection: "column", padding: "6px 22px 0" }}>
                    {" "}
                    {(v.prRows1 || []).map((r, $index) => (
                      <React.Fragment key={$index}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.08)", fontSize: "14px" }}>
                          <span style={{ color: "#b3b9ca" }}>
                            {r.k}
                          </span>
                          <span style={{ color: "#ffffff", textAlign: "right" }}>
                            {r.v}
                          </span>
                        </div>
                      </React.Fragment>
                    ))}
                    {" "}
                    <span style={{ padding: "20px 0 4px", fontSize: "13px", letterSpacing: "0.02em", color: "#8fe3ff" }}>
                      {"Options"}
                    </span>
                    {" "}
                    {(v.prOpt1 || []).map((r, $index) => (
                      <React.Fragment key={$index}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.08)", fontSize: "14px" }}>
                          <span style={{ color: "#c4cadb" }}>
                            {r.k}
                          </span>
                          <span style={{ color: "#ffffff", textAlign: "right" }}>
                            {r.v}
                          </span>
                        </div>
                      </React.Fragment>
                    ))}
                    {" "}
                  </div>
                  {" "}
                  <div style={{ marginTop: "auto", padding: "26px 22px 22px" }}>
                    <a className="adp12" href="#" data-soon="checkout" style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "48px", borderRadius: "12px", background: "#f4f7ff", color: "#0b1230", fontSize: "14px", fontWeight: "500", boxShadow: "0 10px 30px -10px rgba(140,230,255,0.55)" }}>
                      {"Get started with Pro"}
                    </a>
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
              <div data-pr="2" style={{ flex: "1 1 0", width: "100%", maxWidth: "390px", minWidth: "0", display: "flex", opacity: "0", transform: "translate3d(0,70px,0)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                {" "}
                <article className="adp10" style={{ flex: "1", position: "relative", display: "flex", flexDirection: "column", borderRadius: "18px", overflow: "hidden", background: "radial-gradient(75% 42% at 40% 112%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), radial-gradient(60% 40% at 100% 0%, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0) 70%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.16), 0 50px 90px -40px rgba(0,0,0,0.95), 0 30px 70px -30px rgba(72,96,255,0.35)", transition: "transform 0.45s cubic-bezier(0.2,0.8,0.2,1)" }}>
                  {" "}
                  <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: "linear-gradient(180deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 38%, rgba(130,110,255,0.55) 78%, rgba(150,235,255,0.95) 100%)", WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                  <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none" }} />
                  {" "}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: "12px", padding: "40px 22px 18px" }}>
                    {" "}
                    <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                      <span style={{ fontSize: "13px", color: "#9aa3bd" }}>
                        {"Studio"}
                      </span>
                      <span style={{ fontSize: "clamp(24px, 2.7cqw, 32px)", fontWeight: "500", letterSpacing: "-0.04em", lineHeight: "1", whiteSpace: "nowrap", color: "#ffffff" }}>
                        {"1,200 min"}
                      </span>
                    </div>
                    {" "}
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "4px", textAlign: "right" }}>
                      <span style={{ fontSize: "17px", fontWeight: "500", color: "#ffffff" }}>
                        {"$"}
                        {v.pr2.price}
                        {"/month"}
                      </span>
                      <span style={{ fontSize: "12px", color: "#8a92ab" }}>
                        {v.prBill}
                      </span>
                    </div>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: "12px", padding: "14px 22px", background: "radial-gradient(28% 70% at 50% 128%, rgba(140,235,255,0.6) 0%, rgba(140,235,255,0) 100%), radial-gradient(48% 150% at 50% 140%, rgba(110,230,255,0.62) 0%, rgba(72,96,255,0.5) 32%, rgba(98,48,230,0.22) 58%, rgba(98,48,230,0) 80%), linear-gradient(165deg, rgba(34,38,62,0.9) 0%, rgba(18,20,38,0.93) 45%, rgba(11,13,26,0.96) 100%)", borderTop: "1px solid rgba(255,255,255,0.08)", borderBottom: "1px solid transparent", borderImage: "linear-gradient(90deg, rgba(130,110,255,0) 0%, rgba(130,110,255,0.5) 25%, rgba(150,235,255,0.95) 50%, rgba(130,110,255,0.5) 75%, rgba(130,110,255,0) 100%) 0 0 1 0" }}>
                    {" "}
                    <span style={{ display: "flex", alignItems: "baseline", gap: "8px" }}>
                      <span style={{ fontSize: "13px", color: "#d6dcf0" }}>
                        {"From"}
                      </span>
                      <span style={{ fontSize: "26px", fontWeight: "500", letterSpacing: "-0.03em", color: "#ffffff" }}>
                        {"$"}
                        {v.pr2.per}
                      </span>
                    </span>
                    {" "}
                    <span style={{ fontSize: "13px", color: "#d6dcf0" }}>
                      {"per minute"}
                    </span>
                    {" "}
                  </div>
                  {" "}
                  <div style={{ display: "flex", flexDirection: "column", padding: "6px 22px 0" }}>
                    {" "}
                    {(v.prRows2 || []).map((r, $index) => (
                      <React.Fragment key={$index}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: "14px" }}>
                          <span style={{ color: "#a9b0c4" }}>
                            {r.k}
                          </span>
                          <span style={{ color: "#ffffff", textAlign: "right" }}>
                            {r.v}
                          </span>
                        </div>
                      </React.Fragment>
                    ))}
                    {" "}
                    <span style={{ padding: "20px 0 4px", fontSize: "13px", letterSpacing: "0.02em", color: "#8fe3ff" }}>
                      {"Options"}
                    </span>
                    {" "}
                    {(v.prOpt2 || []).map((r, $index) => (
                      <React.Fragment key={$index}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: "14px" }}>
                          <span style={{ color: "#a9b0c4" }}>
                            {r.k}
                          </span>
                          <span style={{ color: "#ffffff", textAlign: "right" }}>
                            {r.v}
                          </span>
                        </div>
                      </React.Fragment>
                    ))}
                    {" "}
                  </div>
                  {" "}
                  <div style={{ marginTop: "auto", padding: "26px 22px 22px" }}>
                    <a className="adp11" href="#" data-soon="sales" style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "48px", borderRadius: "12px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.14)", color: "#ffffff", fontSize: "14px", fontWeight: "500" }}>
                      {"Talk to sales"}
                    </a>
                  </div>
                  {" "}
                </article>
                {" "}
              </div>
              {" "}
            </div>
            {" "}
          </div>
          {" "}
        </section>
        {" "}
        <section ref={v.faqRef} id="faq" data-screen-label="FAQ" aria-label="Frequently asked questions" style={{ position: "relative", background: "#080913", padding: "clamp(60px, 6.2cqw, 100px) clamp(16px, 3cqw, 56px) clamp(80px, 9cqw, 140px)" }}>
          {" "}
          <div style={{ position: "relative", maxWidth: "860px", margin: "0 auto", display: "flex", flexDirection: "column", alignItems: "center", gap: "clamp(32px, 4cqw, 56px)" }}>
            {" "}
            <div data-fq="0" style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", gap: "18px", opacity: "0", transform: "translate3d(0,40px,0)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
              {" "}
              <h2 style={{ margin: "0", fontSize: "clamp(32px, 4.6cqw, 72px)", fontWeight: "500", lineHeight: "1.04", letterSpacing: "-0.045em", background: "linear-gradient(180deg, #ffffff 30%, #a7b4d3 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", textWrap: "balance" }}>
                {"Questions, Answered."}
              </h2>
              {" "}
              <p style={{ margin: "0", maxWidth: "460px", fontSize: "15px", lineHeight: "1.6", color: "#b3b9ca", textWrap: "pretty" }}>
                {"Everything you need to know about dubbing your videos with AutoDub."}
              </p>
              {" "}
            </div>
            {" "}
            <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: "12px" }}>
              {" "}
              {(v.faqItems || []).map((q, $index) => (
                <React.Fragment key={$index}>
                  {" "}
                  <div data-fq={q.d} style={{ opacity: "0", transform: "translate3d(0,40px,0)", transition: "opacity 0.45s ease, transform 0.8s cubic-bezier(0.16,0.84,0.24,1)" }}>
                    {" "}
                    <div style={{ position: "relative", overflow: "hidden", isolation: "isolate", borderRadius: "18px", background: q.bg, boxShadow: "inset 0 1px 0 rgba(255,255,255,0.1), 0 30px 60px -40px rgba(0,0,0,0.9)", transition: "background 0.4s ease" }}>
                      {" "}
                      <div aria-hidden="true" style={{ position: "absolute", inset: "0", borderRadius: "inherit", padding: "1.2px", pointerEvents: "none", background: q.edge, WebkitMask: "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)", WebkitMaskComposite: "xor", mask: "linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)" }} />
                      {" "}
                      <div aria-hidden="true" style={{ position: "absolute", left: "18%", right: "18%", bottom: "-26px", height: "56px", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(140,235,255,0.62), rgba(140,235,255,0.22) 55%, rgba(140,235,255,0))", pointerEvents: "none", opacity: q.glow, transition: "opacity 0.4s ease" }} />
                      {" "}
                      <button aria-expanded={q.exp} onClick={q.toggle} style={{ position: "relative", width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "16px", padding: "22px 24px", border: "0", background: "transparent", font: "inherit", textAlign: "left", color: "#ffffff", cursor: "pointer" }}>
                        {" "}
                        <span style={{ fontSize: "clamp(16px, 1.35cqw, 19px)", fontWeight: "500", letterSpacing: "-0.02em", lineHeight: "1.3" }}>
                          {q.q}
                        </span>
                        {" "}
                        <span aria-hidden="true" style={{ flex: "none", width: "34px", height: "34px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", transform: `rotate(${q.rot}deg)`, transition: "transform 0.35s cubic-bezier(0.2,0.8,0.2,1)" }}>
                          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#e9eef8" strokeWidth="1.8" strokeLinecap="round">
                            <path d="M12 5v14M5 12h14" />
                          </svg>
                        </span>
                        {" "}
                      </button>
                      {" "}
                      <div style={{ position: "relative", display: "grid", gridTemplateRows: q.rows, transition: "grid-template-rows 0.4s cubic-bezier(0.2,0.8,0.2,1)" }}>
                        {" "}
                        <div style={{ overflow: "hidden", minHeight: "0" }}>
                          {" "}
                          <p style={{ margin: "0", padding: "0 24px 24px", maxWidth: "640px", fontSize: "15px", lineHeight: "1.6", color: "#b3b9ca", textWrap: "pretty" }}>
                            {q.a}
                          </p>
                          {" "}
                        </div>
                        {" "}
                      </div>
                      {" "}
                    </div>
                    {" "}
                  </div>
                  {" "}
                </React.Fragment>
              ))}
              {" "}
            </div>
            {" "}
          </div>
          {" "}
        </section>
        {" "}
        <footer data-screen-label="Footer" style={{ position: "relative", overflow: "hidden", isolation: "isolate", background: "#080913", containerType: "inline-size" }}>
          {" "}
          <div aria-hidden="true" style={{ position: "absolute", inset: "0", zIndex: "-1", pointerEvents: "none", background: "radial-gradient(70% 75% at 78% 112%, rgba(110,230,255,0.42) 0%, rgba(72,96,255,0.34) 32%, rgba(98,48,230,0.15) 58%, rgba(98,48,230,0) 80%), radial-gradient(40% 40% at 70% 108%, rgba(140,235,255,0.22) 0%, rgba(140,235,255,0) 100%)" }} />
          {" "}
          <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between", alignItems: "flex-start", gap: v.ftGap, padding: "clamp(40px, 4.5cqw, 64px) clamp(20px, 2.6cqw, 40px) 0" }}>
            {" "}
            <nav aria-label="Footer" style={{ display: "flex", flexDirection: v.ftNavDir, flexWrap: v.ftNavWrap, gap: v.ftNavGap, maxWidth: "100%" }}>
              {" "}
              <a className="adp13" href="#" style={{ fontSize: "clamp(17px, 1.5cqw, 22px)", fontWeight: "500", letterSpacing: "-0.02em", color: "#ffffff", whiteSpace: "nowrap", transition: "color 0.2s ease" }}>
                {"Home"}
              </a>
              {" "}
              <a className="adp13" href="#features" style={{ fontSize: "clamp(17px, 1.5cqw, 22px)", fontWeight: "500", letterSpacing: "-0.02em", color: "#ffffff", whiteSpace: "nowrap", transition: "color 0.2s ease" }}>
                {"Features"}
              </a>
              {" "}
              <a className="adp13" href="#how-it-works" style={{ fontSize: "clamp(17px, 1.5cqw, 22px)", fontWeight: "500", letterSpacing: "-0.02em", color: "#ffffff", whiteSpace: "nowrap", transition: "color 0.2s ease" }}>
                {"How it works"}
              </a>
              {" "}
              <a className="adp13" href="#use-cases" style={{ fontSize: "clamp(17px, 1.5cqw, 22px)", fontWeight: "500", letterSpacing: "-0.02em", color: "#ffffff", whiteSpace: "nowrap", transition: "color 0.2s ease" }}>
                {"Use cases"}
              </a>
              {" "}
              <a className="adp13" href="#pricing" style={{ fontSize: "clamp(17px, 1.5cqw, 22px)", fontWeight: "500", letterSpacing: "-0.02em", color: "#ffffff", whiteSpace: "nowrap", transition: "color 0.2s ease" }}>
                {"Pricing"}
              </a>
              {" "}
              <a className="adp13" href="#faq" style={{ fontSize: "clamp(17px, 1.5cqw, 22px)", fontWeight: "500", letterSpacing: "-0.02em", color: "#ffffff", whiteSpace: "nowrap", transition: "color 0.2s ease" }}>
                {"FAQ"}
              </a>
              {" "}
            </nav>
            {" "}
            <div style={{ display: "flex", flexDirection: "column", alignItems: v.ftAlign, gap: "14px", textAlign: v.ftText }}>
              {" "}
              <div style={{ display: "flex", gap: "10px", marginBottom: "8px" }}>
                {" "}
                <a className="adp14" href="#" data-soon="social" aria-label="YouTube" style={{ width: "44px", height: "44px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", transition: "border-color 0.2s ease" }}>
                  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#e9eef8" strokeWidth="1.6" strokeLinejoin="round">
                    <rect x="3" y="6" width="18" height="12" rx="3.5" />
                    <path d="M10.5 9.5l4 2.5-4 2.5z" fill="#e9eef8" />
                  </svg>
                </a>
                {" "}
                <a className="adp14" href="#" data-soon="social" aria-label="X" style={{ width: "44px", height: "44px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", transition: "border-color 0.2s ease" }}>
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#e9eef8" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M5 5l14 14M19 5L5 19" />
                  </svg>
                </a>
                {" "}
                <a className="adp14" href="#" data-soon="social" aria-label="Instagram" style={{ width: "44px", height: "44px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", transition: "border-color 0.2s ease" }}>
                  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#e9eef8" strokeWidth="1.6">
                    <rect x="4" y="4" width="16" height="16" rx="4.5" />
                    <circle cx="12" cy="12" r="3.6" />
                    <circle cx="17" cy="7" r="0.9" fill="#e9eef8" stroke="none" />
                  </svg>
                </a>
                {" "}
                <a className="adp14" href="#" data-soon="social" aria-label="LinkedIn" style={{ width: "44px", height: "44px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(80% 80% at 30% 20%, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.03) 70%)", border: "1px solid rgba(255,255,255,0.14)", transition: "border-color 0.2s ease" }}>
                  <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="#e9eef8" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M7 10v7M7 7v.01M11 17v-7M11 13.5c0-2 1.3-3.5 3-3.5s3 1.2 3 3.5V17" />
                  </svg>
                </a>
                {" "}
              </div>
              {" "}
              <a className="adp13" href="mailto:hello@autodub.ai" style={{ fontSize: "15px", color: "#d6dcf0" }}>
                {"E-mail: hello@autodub.ai"}
              </a>
              {" "}
              <span style={{ fontSize: "15px", color: "#b3b9ca" }}>
                {"support@autodub.ai"}
              </span>
              {" "}
              <span style={{ fontSize: "14px", color: "#8a92ab" }}>
                {"© 2026 AutoDub. All rights reserved."}
              </span>
              {" "}
            </div>
            {" "}
          </div>
          {" "}
          <div aria-hidden="true" style={{ position: "relative", marginTop: "clamp(28px, 4cqw, 64px)", marginBottom: "-4.6cqw", padding: "0 1.6cqw", fontSize: "23.5cqw", fontWeight: "500", lineHeight: "0.95", letterSpacing: "-0.065em", whiteSpace: "nowrap", textAlign: "center", pointerEvents: "none", userSelect: "none", background: "linear-gradient(180deg, rgba(150,178,240,0.06) 0%, rgba(110,140,255,0.26) 38%, rgba(120,200,255,0.55) 72%, rgba(170,240,255,0.8) 100%)", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", filter: "blur(1.5px)" }}>
            {"AutoDub"}
          </div>
          {" "}
        </footer>
        {" "}
      </div>
      {" "}
      {v.soonOpen ? (
        <>
          {" "}
          <div ref={v.soonRef} role="dialog" aria-modal="true" aria-labelledby="soon-title" style={{ position: "fixed", inset: "0", zIndex: "2000", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "28px", padding: "32px 24px", background: "#080913", fontFamily: "'Geist','Helvetica Neue',Helvetica,Arial,sans-serif", color: "#e6e9f2", textAlign: "center", WebkitFontSmoothing: "antialiased" }}>
            {" "}
            <div aria-hidden="true" style={{ position: "absolute", inset: "0", pointerEvents: "none", background: "radial-gradient(60% 45% at 50% 115%, rgba(110,230,255,0.28) 0%, rgba(72,96,255,0.2) 35%, rgba(98,48,230,0.08) 60%, rgba(98,48,230,0) 80%)" }} />
            {" "}
            <svg aria-hidden="true" focusable="false" viewBox="48 36 252 142" style={{ position: "relative", height: "40px", width: "auto", display: "block", filter: "drop-shadow(0 0 22px rgba(72,96,255,0.45))" }} fill="#ffffff" stroke="#ffffff" strokeWidth="11" strokeLinecap="round">
              <circle cx="60" cy="112" r="6.5" stroke="none" />
              <line x1="85" y1="96" x2="85" y2="129" />
              <line x1="110" y1="90" x2="110" y2="134" />
              <line x1="135" y1="54" x2="135" y2="144" />
              <line x1="160" y1="46" x2="160" y2="154" />
              <line x1="185" y1="59" x2="185" y2="168" />
              <line x1="210" y1="81" x2="210" y2="166" />
              <line x1="235" y1="64" x2="235" y2="136" />
              <line x1="260" y1="94" x2="260" y2="129" />
              <circle cx="287" cy="112" r="6.5" stroke="none" />
            </svg>
            {" "}
            <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center", gap: "14px", maxWidth: "440px" }}>
              {" "}
              <span style={{ fontSize: "13px", letterSpacing: "0.02em", color: "#8fe3ff" }}>
                {"In progress"}
              </span>
              {" "}
              <h2 id="soon-title" style={{ margin: "0", fontSize: "clamp(32px, 7vw, 52px)", fontWeight: "500", lineHeight: "1.05", letterSpacing: "-0.045em", color: "#e9eef8", textWrap: "balance" }}>
                <span style={{ padding: "0 0.04em 0.06em", background: "linear-gradient(180deg, #f1f6ff 0%, #cfdcf3 42%, #9aaccc 78%, #8496bb 100%)", WebkitBoxDecorationBreak: "clone", boxDecorationBreak: "clone", WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent" }}>
                  {v.soonTitle}
                </span>
              </h2>
              {" "}
              <p style={{ margin: "0", fontSize: "15px", lineHeight: "1.6", color: "#b3b9ca", textWrap: "pretty" }}>
                {v.soonText}
              </p>
              {" "}
            </div>
            {" "}
            <button className="adp3 adp2" type="button" onClick={v.soonClose} style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: "10px", height: "48px", padding: "0 22px", border: "0", borderRadius: "999px", font: "inherit", fontSize: "15px", color: "#eef1f8", cursor: "pointer", background: "rgba(255,255,255,0.045)", backdropFilter: "blur(12px) saturate(1.4)", WebkitBackdropFilter: "blur(12px) saturate(1.4)", boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.12), inset 1.5px 1.5px 1px -0.5px rgba(255,255,255,0.4), inset -1.5px -1.5px 1px -0.5px rgba(255,255,255,0.14), 0 8px 24px rgba(0,0,0,0.35)", transition: "background 180ms ease" }}>
              <svg aria-hidden="true" width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="#eef1f8" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 7H2M6.5 2.5L2 7l4.5 4.5" />
              </svg>
              <span>
                {"Back to home"}
              </span>
            </button>
            {" "}
          </div>
          {" "}
        </>
      ) : null}
      {" "}
      </>
    );
  }
}

export default AutoDubLanding;
