/** @type {import('next').NextConfig} */
const nextConfig = {
  // Off on purpose: Strict Mode mounts components twice in dev, which would replay the preloader.
  reactStrictMode: false,
};

export default nextConfig;
