import './globals.css';

export const metadata = {
  title: 'AutoDub — Automated Video Dubbing in Every Language',
  description: 'Dub any video into 130+ languages with cloned voices, lip sync and preserved background audio.',
  openGraph: {
    title: 'AutoDub — Automated Video Dubbing in Every Language',
    description: 'Dub any video into 130+ languages with cloned voices, lip sync and preserved background audio.',
    type: 'website',
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#080913',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Geist:wght@200;400;500;600&family=Pinyon+Script&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  );
}
