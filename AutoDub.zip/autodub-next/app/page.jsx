import AutoDubLanding from '@/components/AutoDubLanding';

export default function Home() {
  return <AutoDubLanding />;
}
